package com.github.jwtauthentication.statics;

public enum Roles {

    USER,
    ADMIN;

}
