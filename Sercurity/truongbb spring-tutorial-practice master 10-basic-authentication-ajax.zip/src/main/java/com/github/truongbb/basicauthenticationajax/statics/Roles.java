package com.github.truongbb.basicauthenticationajax.statics;

public enum Roles {

    USER,
    ADMIN;

}
