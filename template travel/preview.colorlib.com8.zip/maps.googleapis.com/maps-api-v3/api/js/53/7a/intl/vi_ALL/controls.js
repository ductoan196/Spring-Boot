google.maps.__gjsload__('controls', function(_) {
    var Nva, Ova, FH, Pva, GH, Qva, Rva, JH, Tva, Uva, Vva, Wva, KH, Xva, Zva, LH, MH, NH, $va, OH, cwa, bwa, awa, PH, RH, ewa, fwa, gwa, hwa, iwa, jwa, dwa, SH, VH, lwa, kwa, WH, XH, nwa, mwa, owa, pwa, qwa, ZH, $H, twa, rwa, swa, uwa, aI, xwa, wwa, cI, eI, dI, fI, zwa, Awa, Bwa, gI, Cwa, hI, Dwa, iI, jI, Fwa, Ewa, Gwa, Hwa, kI, mI, lI, oI, Iwa, Kwa, pI, Lwa, qI, Mwa, Pwa, Nwa, Owa, Swa, Rwa, Qwa, Uwa, rI, Vwa, sI, tI, uI, Ywa, Xwa, Wwa, vI, Zwa, $wa, axa, bxa, wI, cxa, dxa, fxa, exa, xI, gxa, ixa, hxa, yI, AI, jxa, kxa, BI, lxa, DI, CI, EI, FI, GI, mxa, HI, II, nxa, JI, rxa, oxa, pxa, qxa, sxa, txa, KI, uxa, vxa, yxa, zxa, wxa, LI,
        Axa, Cxa, Dxa, Bxa, NI, MI, Exa, Fxa, Gxa, OI, Qxa, Mxa, Sxa, Yxa, QI, PI, Zxa, Pxa, Rxa, Jxa, Lxa, $xa, Kxa, Oxa, Txa, Ixa, bya, cya, dya, eya, fya, RI, Hxa, Vxa, Xxa, Wxa, Uxa, SI, Nxa, gya, hya, aya, TI, UI, VI, kya, WI, XI, YI, lya, mya, nya, ZI, $I, oya, pya, aJ, qya, sya, rya, bJ, Yva;
    Nva = function(a, b) {
        switch (_.Hy(b)) {
            case 1:
                "ltr" !== a.dir && (a.dir = "ltr");
                break;
            case -1:
                "rtl" !== a.dir && (a.dir = "rtl");
                break;
            default:
                a.removeAttribute("dir")
        }
    };
    Ova = function(a, b, c) {
        _.Hq(a, b, "animate", c)
    };
    FH = function(a) {
        a.style.textAlign = _.tw.Tb() ? "right" : "left"
    };
    Pva = function(a, b) {
        if (!(b instanceof _.rb || b instanceof _.rb)) {
            b = "object" == typeof b && b.Rg ? b.Zc() : String(b);
            b: {
                var c = b;
                if (_.$ea) {
                    try {
                        var d = new URL(c)
                    } catch (e) {
                        c = "https:";
                        break b
                    }
                    c = d.protocol
                } else c: {
                    d = document.createElement("a");
                    try {
                        d.href = c
                    } catch (e) {
                        c = void 0;
                        break c
                    }
                    c = d.protocol;c = ":" === c || "" === c ? "https:" : c
                }
            }
            "javascript:" !== c || (b = "about:invalid#zClosurez");
            b = _.sb(b)
        }
        a.href = _.Tm(b)
    };
    GH = function(a) {
        return a ? "none" !== a.style.display : !1
    };
    Qva = function(a, b, c) {
        for (var d = "string" === typeof a ? a.split("") : a, e = a.length - 1; 0 <= e; --e) e in d && b.call(c, d[e], e, a)
    };
    Rva = function(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    };
    _.HH = function(a, b) {
        a.classList ? a.classList.remove(b) : _.Mha(a, b) && _.Lha(a, Array.prototype.filter.call(a.classList ? a.classList : _.In(a).match(/\S+/g) || [], function(c) {
            return c != b
        }).join(" "))
    };
    _.IH = function(a) {
        _.HH(a, "gmnoscreen");
        _.Jn(a, "gmnoprint")
    };
    _.Sva = function(a) {
        _.bj.cd ? a.style.styleFloat = "left" : a.style.cssFloat = "left"
    };
    JH = function(a, b) {
        a.style.WebkitBorderRadius = b;
        a.style.borderRadius = b;
        a.style.MozBorderRadius = b
    };
    Tva = function(a, b) {
        a.style.WebkitBorderTopLeftRadius = b;
        a.style.WebkitBorderTopRightRadius = b;
        a.style.borderTopLeftRadius = b;
        a.style.borderTopRightRadius = b;
        a.style.MozBorderTopLeftRadius = b;
        a.style.MozBorderTopRightRadius = b
    };
    Uva = function(a, b) {
        a.style.WebkitBorderBottomLeftRadius = b;
        a.style.WebkitBorderBottomRightRadius = b;
        a.style.borderBottomLeftRadius = b;
        a.style.borderBottomRightRadius = b;
        a.style.MozBorderBottomLeftRadius = b;
        a.style.MozBorderBottomRightRadius = b
    };
    Vva = function(a) {
        var b = _.jn(2);
        a.style.WebkitBorderBottomLeftRadius = b;
        a.style.WebkitBorderTopLeftRadius = b;
        a.style.borderBottomLeftRadius = b;
        a.style.borderTopLeftRadius = b;
        a.style.MozBorderBottomLeftRadius = b;
        a.style.MozBorderTopLeftRadius = b
    };
    Wva = function(a) {
        var b = _.jn(2);
        a.style.WebkitBorderBottomRightRadius = b;
        a.style.WebkitBorderTopRightRadius = b;
        a.style.borderBottomRightRadius = b;
        a.style.borderTopRightRadius = b;
        a.style.MozBorderBottomRightRadius = b;
        a.style.MozBorderTopRightRadius = b
    };
    KH = function(a, b) {
        b = b || {};
        var c = a.style;
        c.color = "black";
        c.fontFamily = "Roboto,Arial,sans-serif";
        _.eo(a);
        _.co(a);
        b.title && a.setAttribute("title", b.title);
        c = _.go() ? 1.38 : 1;
        a = a.style;
        a.fontSize = _.jn(b.fontSize || 11);
        a.backgroundColor = "#fff";
        for (var d = [], e = 0, f = _.Pd(b.padding); e < f; ++e) d.push(_.jn(c * b.padding[e]));
        a.padding = d.join(" ");
        b.width && (a.width = _.jn(c * b.width))
    };
    Xva = function() {
        return _.Cga.some(function(a) {
            return !!document[a]
        })
    };
    Zva = function(a, b) {
        var c = Yva[b];
        if (!c) {
            var d = Rva(b);
            c = d;
            void 0 === a.style[d] && (d = _.EA() + _.Fpa(d), void 0 !== a.style[d] && (c = d));
            Yva[b] = c
        }
        return c
    };
    LH = function(a, b, c) {
        if ("string" === typeof b)(b = Zva(a, b)) && (a.style[b] = c);
        else
            for (var d in b) {
                c = a;
                var e = b[d],
                    f = Zva(c, d);
                f && (c.style[f] = e)
            }
    };
    MH = function(a, b, c) {
        if (b instanceof _.kn) {
            var d = b.x;
            b = b.y
        } else d = b, b = c;
        a.style.left = _.FA(d, !1);
        a.style.top = _.FA(b, !1)
    };
    NH = function(a) {
        return 40 < a ? a / 2 - 2 : 28 > a ? a - 10 : 18
    };
    $va = function(a, b) {
        _.Gua(a, b);
        b = a.items[b];
        return {
            url: _.Nk(a.jd.url, !a.jd.wl, a.jd.wl),
            size: a.Id,
            scaledSize: a.jd.size,
            origin: b.jf,
            anchor: a.anchor
        }
    };
    OH = function(a, b, c, d, e, f, g) {
        this.label = a || "";
        this.alt = b || "";
        this.o = f || null;
        this.Ff = c;
        this.g = d;
        this.j = e;
        this.h = g || null
    };
    cwa = function(a, b) {
        var c = this;
        this.o = a;
        this.mapping = {};
        this.buttons = [];
        this.h = this.j = this.g = null;
        b = b || ["roadmap", "satellite", "hybrid", "terrain"];
        var d = _.nb(b, "terrain") && _.nb(b, "roadmap"),
            e = _.nb(b, "hybrid") && _.nb(b, "satellite");
        _.M(this, "maptypeid_changed", function() {
            var k = c.get("mapTypeId");
            c.h && c.h.set("display", "satellite" === k);
            c.g && c.g.set("display", "roadmap" === k)
        });
        _.M(this, "zoom_changed", function() {
            if (c.g) {
                var k = c.get("zoom");
                c.g.set("enabled", k <= c.j)
            }
        });
        b = _.A(b);
        for (var f = b.next(); !f.done; f =
            b.next())
            if (f = f.value, "hybrid" !== f || !e)
                if ("terrain" !== f || !d) {
                    var g = a.get(f);
                    if (g) {
                        var h = null;
                        "roadmap" === f ? d && (this.g = awa(this, "terrain", "roadmap", "terrain", void 0, "Thu nh\u1ecf \u0111\u1ec3 hi\u1ec3n th\u1ecb b\u1ea3n \u0111\u1ed3 ph\u1ed1 c\u00f3 \u0111\u1ecba h\u00ecnh"), h = [
                            [this.g]
                        ], this.j = a.get("terrain").maxZoom) : "satellite" !== f && "hybrid" !== f || !e || (this.h = bwa(this), h = [
                            [this.h]
                        ]);
                        this.buttons.push(new OH(g.name, g.alt, "mapTypeId", f, null, null, h))
                    }
                }
    };
    bwa = function(a) {
        a = awa(a, "hybrid", "satellite", "labels", "Nh\u00e3n");
        a.set("enabled", !0);
        return a
    };
    awa = function(a, b, c, d, e, f) {
        var g = a.o.get(b);
        e = new OH(e || g.name, g.alt, d, !0, !1, f);
        a.mapping[b] = {
            mapTypeId: c,
            Ml: d,
            value: !0
        };
        a.mapping[c] = {
            mapTypeId: c,
            Ml: d,
            value: !1
        };
        return e
    };
    PH = function(a) {
        this.h = a;
        this.g = null
    };
    RH = function(a) {
        _.GC.call(this, a, QH);
        _.YB(a, QH) || _.XB(a, QH, {
            options: 0
        }, ["div", , 1, 0, [" ", ["img", 8, 1, 1], " ", ["button", , 1, 2, [" ", ["img", 8, 1, 3], " ", ["img", 8, 1, 4], " ", ["img", 8, 1, 5], " "]], " ", ["button", , 1, 6, [" ", ["img", 8, 1, 7], " ", ["img", 8, 1, 8], " ", ["img", 8, 1, 9], " "]], " ", ["button", , 1, 10, [" ", ["img", 8, 1, 11], " ", ["img", 8, 1, 12], " ", ["img", 8, 1, 13], " "]], " <div> ", ["div", , , 14, ["Xoay ch\u1ebf \u0111\u1ed9 xem"]], " ", ["div", , , 15], " ", ["div", , , 16], " </div> "]], [], dwa())
    };
    ewa = function(a) {
        return _.W(a.options, "", -10)
    };
    fwa = function(a) {
        return _.W(a.options, "", -7, -3)
    };
    gwa = function(a) {
        return _.W(a.options, "", -8, -3)
    };
    hwa = function(a) {
        return _.W(a.options, "", -9, -3)
    };
    iwa = function(a) {
        return _.W(a.options, "", -12)
    };
    jwa = function(a) {
        return _.W(a.options, "", -11)
    };
    dwa = function() {
        return [
            ["$t", "t-avKK8hDgg9Q", "$a", [7, , , , , "gm-compass"]],
            ["$a", [8, , , , function(a) {
                return _.W(a.options, "", -3, -3)
            }, "src", , , 1], "$a", [0, , , , "", "alt", , 1], "$a", [0, , , , "48", "height", , 1], "$a", [0, , , , "48", "width", , 1]],
            ["$a", [7, , , , , "gm-control-active", , 1], "$a", [7, , , , , "gm-compass-turn", , 1], "$a", [0, , , , ewa, "aria-label", , , 1], "$a", [0, , , , ewa, "title", , , 1], "$a", [0, , , , "button", "type", , 1], "$a", [22, , , , function() {
                return "compass.counterclockwise"
            }, "jsaction", , 1]],
            ["$a", [8, , , , fwa, "src", , , 1], "$a", [0, , , , "", "alt", , 1], "$a", [0, , , , "false", "draggable", , 1], "$a", [0, , , , "48", "height", , 1], "$a", [0, , , , "14", "width", , 1]],
            ["$a", [8, , , , gwa, "src", , , 1], "$a", [0, , , , "", "alt", , 1], "$a", [0, , , , "false", "draggable", , 1], "$a", [0, , , , "48", "height", , 1], "$a", [0, , , , "14", "width", , 1]],
            ["$a", [8, , , , hwa, "src", , , 1], "$a", [0, , , , "", "alt", , 1], "$a", [0, , , , "false", "draggable", , 1], "$a", [0, , , , "48", "height", , 1], "$a", [0, , , , "14", "width", , 1]],
            ["$a", [7, , , , , "gm-control-active", , 1], "$a", [7, , , , , "gm-compass-needle", , 1], "$a", [0, , , , iwa, "aria-label", , , 1], "$a", [5, 5, , , function(a) {
                return a.ub ? _.vB("-webkit-transform", "rotate(" + String(_.W(a.options, 0, -1)) + "deg)") : "rotate(" + String(_.W(a.options, 0, -1)) + "deg)"
            }, "-webkit-transform", , , 1], "$a", [5, 5, , , function(a) {
                return a.ub ? _.vB("-ms-transform", "rotate(" + String(_.W(a.options, 0, -1)) + "deg)") : "rotate(" + String(_.W(a.options, 0, -1)) + "deg)"
            }, "-ms-transform", , , 1], "$a", [5, 5, , , function(a) {
                return a.ub ? _.vB("-moz-transform", "rotate(" + String(_.W(a.options, 0, -1)) + "deg)") : "rotate(" + String(_.W(a.options, 0, -1)) + "deg)"
            }, "-moz-transform", , , 1], "$a", [5, 5, , , function(a) {
                return a.ub ? _.vB("transform", "rotate(" + String(_.W(a.options, 0, -1)) + "deg)") : "rotate(" + String(_.W(a.options, 0, -1)) + "deg)"
            }, "transform", , , 1], "$a", [0, , , , iwa, "title", , , 1], "$a", [0, , , , "button", "type", , 1], "$a", [22, , , , function() {
                return "compass.north"
            }, "jsaction", , 1]],
            ["$a", [8, , , , function(a) {
                return _.W(a.options, "", -4, -3)
            }, "src", , , 1], "$a", [0, , , , "", "alt", , 1], "$a", [0, , , , "false", "draggable", , 1], "$a", [0, , , , "48", "height", , 1], "$a", [0, , , , "20", "width", , 1]],
            ["$a", [8, , , , function(a) {
                return _.W(a.options,
                    "", -5, -3)
            }, "src", , , 1], "$a", [0, , , , "", "alt", , 1], "$a", [0, , , , "false", "draggable", , 1], "$a", [0, , , , "48", "height", , 1], "$a", [0, , , , "20", "width", , 1]],
            ["$a", [8, , , , function(a) {
                return _.W(a.options, "", -6, -3)
            }, "src", , , 1], "$a", [0, , , , "", "alt", , 1], "$a", [0, , , , "false", "draggable", , 1], "$a", [0, , , , "48", "height", , 1], "$a", [0, , , , "20", "width", , 1]],
            ["$a", [7, , , , , "gm-control-active", , 1], "$a", [7, , , , , "gm-compass-turn", , 1], "$a", [7, , , , , "gm-compass-turn-opposite", , 1], "$a", [0, , , , jwa, "aria-label", , , 1], "$a", [0, , , , jwa, "title", , , 1], "$a", [0, , , , "button", "type", , 1], "$a", [22, , , , function() {
                return "compass.clockwise"
            }, "jsaction", , 1]],
            ["$a", [8, , , , fwa, "src", , , 1], "$a", [0, , , , "", "alt", , 1], "$a", [0, , , , "false", "draggable", , 1], "$a", [0, , , , "48", "height", , 1], "$a", [0, , , , "14", "width", , 1]],
            ["$a", [8, , , , gwa, "src", , , 1], "$a", [0, , , , "", "alt", , 1], "$a", [0, , , , "false", "draggable", , 1], "$a", [0, , , , "48", "height", , 1], "$a", [0, , , , "14", "width", , 1]],
            ["$a", [8, , , , hwa, "src", , , 1], "$a", [0, , , , "", "alt", , 1], "$a", [0, , , , "false", "draggable", , 1], "$a", [0, , , , "48", "height", , 1], "$a", [0, , , , "14", "width", , 1]],
            ["$a", [7, , , , , "gm-compass-tooltip-text", , 1]],
            ["$a", [7, , , , , "gm-compass-arrow-right", , 1], "$a", [7, , , , , "gm-compass-arrow-right-outer", , 1]],
            ["$a", [7, , , , , "gm-compass-arrow-right", , 1], "$a", [7, , , , , "gm-compass-arrow-right-inner", , 1]]
        ]
    };
    SH = function(a) {
        _.F.call(this, a)
    };
    VH = function(a) {
        a = _.Oa(a);
        delete TH[a];
        _.eb(TH) && UH && UH.stop()
    };
    lwa = function() {
        UH || (UH = new _.Ii(function() {
            kwa()
        }, 20));
        var a = UH;
        a.isActive() || a.start()
    };
    kwa = function() {
        var a = _.Ra();
        _.Rl(TH, function(b) {
            mwa(b, a)
        });
        _.eb(TH) || lwa()
    };
    WH = function() {
        _.Ci.call(this);
        this.g = 0;
        this.endTime = this.startTime = null
    };
    XH = function(a, b, c, d) {
        WH.call(this);
        if (!Array.isArray(a) || !Array.isArray(b)) throw Error("Start and end parameters must be arrays");
        if (a.length != b.length) throw Error("Start and end points must be the same length");
        this.o = a;
        this.D = b;
        this.duration = c;
        this.C = d;
        this.coords = [];
        this.progress = 0
    };
    nwa = function(a) {
        if (0 == a.g) a.progress = 0, a.coords = a.o;
        else if (1 == a.g) return;
        VH(a);
        var b = _.Ra();
        a.startTime = b; - 1 == a.g && (a.startTime -= a.duration * a.progress);
        a.endTime = a.startTime + a.duration;
        a.progress || a.h("begin");
        a.h("play"); - 1 == a.g && a.h("resume");
        a.g = 1;
        var c = _.Oa(a);
        c in TH || (TH[c] = a);
        lwa();
        mwa(a, b)
    };
    mwa = function(a, b) {
        b < a.startTime && (a.endTime = b + a.endTime - a.startTime, a.startTime = b);
        a.progress = (b - a.startTime) / (a.endTime - a.startTime);
        1 < a.progress && (a.progress = 1);
        owa(a, a.progress);
        1 == a.progress ? (a.g = 0, VH(a), a.h("finish"), a.h("end")) : 1 == a.g && a.h("animate")
    };
    owa = function(a, b) {
        "function" === typeof a.C && (b = a.C(b));
        a.coords = Array(a.o.length);
        for (var c = 0; c < a.o.length; c++) a.coords[c] = (a.D[c] - a.o[c]) * b + a.o[c]
    };
    pwa = function(a, b) {
        _.$h.call(this, a);
        this.coords = b.coords;
        this.x = b.coords[0];
        this.y = b.coords[1];
        this.z = b.coords[2];
        this.duration = b.duration;
        this.progress = b.progress;
        this.state = b.g
    };
    qwa = function(a) {
        return 3 * a * a - 2 * a * a * a
    };
    ZH = function(a, b, c) {
        var d = this;
        this.h = a;
        b /= 40;
        a.ra.style.transform = "scale(" + b + ")";
        a.ra.style.transformOrigin = "left";
        a.ra.dataset.controlWidth = String(Math.round(48 * b));
        a.ra.dataset.controlHeight = String(Math.round(48 * b));
        a.addListener("compass.clockwise", "click", function(e) {
            return rwa(d, e, !0)
        });
        a.addListener("compass.counterclockwise", "click", function(e) {
            return rwa(d, e, !1)
        });
        a.addListener("compass.north", "click", function(e) {
            var f = d.get("pov");
            if (f) {
                var g = _.cn(f.heading, 360);
                swa(d, g, 180 > g ? 0 : 360, f.pitch,
                    0);
                twa(e)
            }
        });
        this.g = null;
        this.j = !1;
        _.Nm(YH, c)
    };
    $H = function(a) {
        var b = a.get("mapSize"),
            c = a.get("panControl"),
            d = !!a.get("disableDefaultUI");
        a.h.ra.style.visibility = c || void 0 === c && !d && b && 200 <= b.width && 200 <= b.height ? "" : "hidden";
        _.N(a.h.ra, "resize")
    };
    twa = function(a) {
        var b = _.kA(a) ? "Cmcmi" : "Cmcki";
        _.P(window, _.kA(a) ? 171336 : 171335);
        _.Q(window, b)
    };
    rwa = function(a, b, c) {
        var d = a.get("pov");
        if (d) {
            var e = _.cn(d.heading, 360);
            swa(a, e, c ? 90 * Math.floor((e + 100) / 90) : 90 * Math.ceil((e - 100) / 90), d.pitch, d.pitch);
            twa(b)
        }
    };
    swa = function(a, b, c, d, e) {
        var f = new _.Gq;
        a.g && a.g.stop();
        b = a.g = new XH([b, d], [c, e], 1200, qwa);
        Ova(f, b, function(g) {
            return uwa(a, !1, g)
        });
        _.ppa(f, b, "finish", function(g) {
            return uwa(a, !0, g)
        });
        nwa(b)
    };
    uwa = function(a, b, c) {
        a.j = !0;
        var d = a.get("pov");
        d && (a.set("pov", {
            heading: c.coords[0],
            pitch: c.coords[1],
            zoom: d.zoom
        }), a.j = !1, b && (a.g = null))
    };
    aI = function(a, b, c, d) {
        a.innerText = "";
        b = _.A(b ? 1 == c ? [_.Nr["fullscreen_exit_normal_dark.svg"], _.Nr["fullscreen_exit_hover_dark.svg"], _.Nr["fullscreen_exit_active_dark.svg"]] : [_.Nr["fullscreen_exit_normal.svg"], _.Nr["fullscreen_exit_hover.svg"], _.Nr["fullscreen_exit_active.svg"]] : 1 == c ? [_.Nr["fullscreen_enter_normal_dark.svg"], _.Nr["fullscreen_enter_hover_dark.svg"], _.Nr["fullscreen_enter_active_dark.svg"]] : [_.Nr["fullscreen_enter_normal.svg"], _.Nr["fullscreen_enter_hover.svg"], _.Nr["fullscreen_enter_active.svg"]]);
        for (c = b.next(); !c.done; c = b.next()) {
            c = c.value;
            var e = document.createElement("img");
            e.style.width = e.style.height = _.jn(NH(d));
            e.src = c;
            e.alt = "";
            a.appendChild(e)
        }
    };
    xwa = function(a, b, c, d) {
        var e = this;
        this.j = a;
        this.o = d;
        this.g = b;
        this.g.style.cursor = "pointer";
        this.g.setAttribute("aria-pressed", !1);
        this.xd = c;
        this.h = Xva();
        this.C = [];
        this.D = function() {
            e.xd.set(_.Ida(e.j))
        };
        this.refresh = function() {
            var f = e.get("display"),
                g = !!e.get("disableDefaultUI");
            _.eA(e.g, (void 0 === f && !g || !!f) && e.h);
            _.N(e.g, "resize")
        };
        this.h && (_.Nm(YH, a), this.g.setAttribute("class", "gm-control-active gm-fullscreen-control"), JH(this.g, _.jn(_.MC(d))), this.g.style.width = this.g.style.height = _.jn(d), _.jA(this.g,
            "0 1px 4px -1px rgba(0,0,0,0.3)"), a = this.get("controlStyle") || 0, aI(this.g, this.xd.get(), a, d), this.g.style.overflow = "hidden", _.mf(this.g, "click", function(f) {
            var g = _.kA(f) ? 164676 : 164675;
            _.Q(window, _.kA(f) ? "Fscmi" : "Fscki");
            _.P(window, g);
            if (e.xd.get()) {
                f = _.A(_.Aga);
                for (g = f.next(); !g.done; g = f.next())
                    if (g = g.value, g in document) {
                        document[g]();
                        break
                    }
                e.g.setAttribute("aria-pressed", !1)
            } else {
                f = _.A(_.Bga);
                for (g = f.next(); !g.done; g = f.next()) e.C.push(_.mf(document, g.value, e.D));
                f = e.j;
                g = _.A(_.Dga);
                for (var h = g.next(); !h.done; h =
                    g.next())
                    if (h = h.value, h in f) {
                        f[h]();
                        break
                    }
                e.g.setAttribute("aria-pressed", !0)
            }
        }));
        _.M(this, "disabledefaultui_changed", this.refresh);
        _.M(this, "display_changed", this.refresh);
        _.M(this, "maptypeid_changed", function() {
            var f = "streetview" == e.get("mapTypeId") ? 1 : 0;
            e.set("controlStyle", f);
            e.g.style.margin = _.jn(e.o >> 2);
            e.refresh()
        });
        _.M(this, "controlstyle_changed", function() {
            var f = e.get("controlStyle");
            null != f && (e.g.style.backgroundColor = vwa[f].backgroundColor, e.h && aI(e.g, e.xd.get(), f, e.o))
        });
        this.xd.addListener(function() {
            _.N(e.j,
                "resize");
            e.xd.get() || wwa(e);
            if (e.h) {
                var f = e.get("controlStyle") || 0;
                aI(e.g, e.xd.get(), f, e.o)
            }
        });
        this.refresh()
    };
    wwa = function(a) {
        for (var b = _.A(a.C), c = b.next(); !c.done; c = b.next()) _.gf(c.value);
        a.C.length = 0
    };
    _.bI = function(a, b) {
        b = void 0 === b ? document.head : b;
        _.eo(a);
        _.co(a);
        _.Nm(ywa, b);
        _.Jn(a, "gm-style-cc");
        a.style.position = "relative";
        b = _.ao("div", a);
        _.ao("div", b).style.width = _.jn(1);
        var c = a.T = _.ao("div", b);
        c.style.backgroundColor = "#f5f5f5";
        c.style.width = "auto";
        c.style.height = "100%";
        c.style.marginLeft = _.jn(1);
        _.hA(b, .7);
        b.style.width = "100%";
        b.style.height = "100%";
        _.Zn(b);
        b = a.j = _.ao("div", a);
        b.style.position = "relative";
        b.style.paddingLeft = b.style.paddingRight = _.jn(6);
        b.style.boxSizing = "border-box";
        b.style.fontFamily =
            "Roboto,Arial,sans-serif";
        b.style.fontSize = _.jn(10);
        b.style.color = "#000000";
        b.style.whiteSpace = "nowrap";
        b.style.direction = "ltr";
        b.style.textAlign = "right";
        a.style.height = _.jn(14);
        a.style.lineHeight = _.jn(14);
        b.style.verticalAlign = "middle";
        b.style.display = "inline-block";
        return b
    };
    cI = function(a) {
        a.T && (a.T.style.backgroundColor = "#000", a.j.style.color = "#fff")
    };
    eI = function(a, b, c) {
        _.IH(a);
        _.bo(a, 1000001);
        this.fa = a;
        this.j = c;
        this.h = _.ao("div", a);
        this.o = _.bI(this.h, b);
        2 === c && cI(this.h);
        a = _.Mr("Ph\u00edm t\u1eaft");
        this.o.appendChild(a);
        a.textContent = "Ph\u00edm t\u1eaft";
        a.style.color = 1 === this.j ? "#000000" : "#fff";
        a.style.display = "inline-block";
        a.style.fontFamily = "inherit";
        a.style.lineHeight = "inherit";
        _.cA(a, "click", this);
        this.g = a;
        a = new Image;
        a.src = 1 === this.j ? _.Nr["keyboard_icon.svg"] : _.Nr["keyboard_icon_dark.svg"];
        a.alt = "";
        a.style.height = "10px";
        a.style.width =
            "16px";
        a.style.verticalAlign = "middle";
        this.C = a;
        dI(this)
    };
    dI = function(a) {
        _.Ca(function(b) {
            _.N(a.fa, "resize");
            _.wa(b)
        })
    };
    fI = function(a, b) {
        var c = this;
        this.h = a;
        this.j = b;
        this.g = document.activeElement === this.element;
        this.fa = _.ao("div");
        this.element = zwa(this);
        Awa(this);
        _.mf(this.element, "focus", function() {
            c.Qp()
        });
        _.mf(this.element, "blur", function() {
            c.g = !1;
            Awa(c)
        });
        _.M(this, "update", function() {
            c.g && Bwa(c)
        });
        _.qf(a, "update", this)
    };
    zwa = function(a) {
        var b = _.Mr("Ph\u00edm t\u1eaft");
        a.fa.appendChild(b);
        _.bo(b, 1000002);
        b.style.position = "absolute";
        b.style.backgroundColor = "transparent";
        b.style.border = "none";
        b.style.outlineOffset = "3px";
        _.cA(b, "click", a.h.g);
        return b
    };
    Awa = function(a) {
        a.element.style.right = "0px";
        a.element.style.bottom = "0px";
        a.element.style.transform = "translateX(100%)"
    };
    Bwa = function(a) {
        var b = a.h.g.getBoundingClientRect(),
            c = b.height,
            d = b.width,
            e = b.bottom;
        b = b.right;
        var f = a.j.getBoundingClientRect(),
            g = f.bottom;
        f = f.right;
        a.element.style.transform = "";
        a.element.style.height = c + "px";
        a.element.style.width = d + "px";
        a.element.style.bottom = g - e + "px";
        a.element.style.right = f - b + "px"
    };
    gI = function(a, b, c) {
        this.fa = a;
        this.padding = void 0 === c ? 0 : c;
        this.elements = [];
        this.h = (this.g = 3 === b || 12 === b || 6 === b || 9 === b) ? Qva.bind(this) : _.mb.bind(this);
        a.dataset.controlWidth = "0";
        a.dataset.controlHeight = "0"
    };
    Cwa = function(a, b) {
        var c = {
            element: b,
            height: 0,
            width: 0,
            dr: _.M(b, "resize", function() {
                return void hI(a, c)
            })
        };
        return c
    };
    hI = function(a, b) {
        b.width = _.Yd(b.element.dataset.controlWidth);
        b.height = _.Yd(b.element.dataset.controlHeight);
        b.width || (b.width = b.element.offsetWidth);
        b.height || (b.height = b.element.offsetHeight);
        var c = 0;
        b = _.A(a.elements);
        for (var d = b.next(); !d.done; d = b.next()) {
            var e = d.value;
            d = e.element;
            e = e.width;
            GH(d) && "hidden" !== d.style.visibility && (c = Math.max(c, e))
        }
        var f = 0,
            g = !1,
            h = a.padding;
        a.h(a.elements, function(k) {
            var l = k.element,
                m = k.height;
            k = k.width;
            GH(l) && "hidden" !== l.style.visibility && (g ? f += h : g = !0, l.style.left =
                _.jn((c - k) / 2), l.style.top = _.jn(f), f += m)
        });
        b = c;
        d = f;
        a.fa.dataset.controlWidth = "" + b;
        a.fa.dataset.controlHeight = "" + d;
        _.eA(a.fa, !(!b && !d));
        _.N(a.fa, "resize")
    };
    Dwa = function(a, b) {
        var c = "B\u1ea1n \u0111ang s\u1eed d\u1ee5ng tr\u00ecnh duy\u1ec7t kh\u00f4ng \u0111\u01b0\u1ee3c API JavaScript cu\u0309a Google Maps h\u00f4\u0303 tr\u01a1\u0323. Vui l\u00f2ng c\u00e2n nh\u1eafc vi\u1ec7c thay \u0111\u1ed5i tr\u00ecnh duy\u1ec7t c\u1ee7a b\u1ea1n.",
            d = document.createElement("div");
        d.className = "infomsg";
        a.appendChild(d);
        var e = d.style;
        e.background = "#F9EDBE";
        e.border = "1px solid #F0C36D";
        e.borderRadius = "2px";
        e.boxSizing = "border-box";
        e.boxShadow = "0 2px 4px rgba(0,0,0,0.2)";
        e.fontFamily = "Roboto,Arial,sans-serif";
        e.fontSize = "12px";
        e.fontWeight = "400";
        e.left = "10%";
        e.g = "2px";
        e.padding = "5px 14px";
        e.position = "absolute";
        e.textAlign = "center";
        e.top = "10px";
        e.webkitBorderRadius = "2px";
        e.width = "80%";
        e.zIndex = 24601;
        d.innerText = c;
        c = document.createElement("a");
        b && (d.appendChild(document.createTextNode(" ")), d.appendChild(c), c.innerText = "T\u00ecm hi\u1ec3u th\u00eam", c.href = b, c.target = "_blank");
        b = document.createElement("a");
        d.appendChild(document.createTextNode(" "));
        d.appendChild(b);
        b.innerText = "Lo\u1ea1i b\u1ecf";
        b.target = "_blank";
        c.style.paddingLeft = b.style.paddingLeft = "0.8em";
        c.style.boxSizing = b.style.boxSizing = "border-box";
        c.style.color = b.style.color = "black";
        c.style.cursor = b.style.cursor = "pointer";
        c.style.textDecoration = b.style.textDecoration = "underline";
        c.style.whiteSpace = b.style.whiteSpace = "nowrap";
        b.onclick = function() {
            a.removeChild(d)
        }
    };
    iI = function(a) {
        this.g = a.replace("www.google", "maps.google")
    };
    jI = function(a, b, c) {
        var d = this;
        this.C = a;
        this.D = c;
        this.j = _.ao("div");
        this.j.style.margin = "0 5px";
        this.j.style.zIndex = 1E6;
        this.g = _.ao("a");
        this.g.style.display = "inline";
        this.g.target = "_blank";
        this.g.rel = "noopener";
        this.g.title = "M\u1edf khu v\u1ef1c n\u00e0y trong Google Maps (m\u1edf c\u1eeda s\u1ed5 m\u1edbi)";
        this.g.setAttribute("aria-label", "M\u1edf khu v\u1ef1c n\u00e0y trong Google Maps (m\u1edf c\u1eeda s\u1ed5 m\u1edbi)");
        _.en(this.g, _.vz(b.get("url")));
        this.g.addEventListener("click", function(e) {
            var f =
                _.kA(e) ? 165230 : 165229;
            _.Q(window, _.kA(e) ? "Lcmi" : "Lcki");
            _.P(window, f)
        });
        this.o = _.ao("div");
        a = new _.Fg(66, 26);
        _.gj(this.o, a);
        _.eo(this.o);
        this.h = _.mG(null, this.o, _.nh, a);
        this.h.alt = "Google";
        _.M(b, "url_changed", function() {
            _.en(d.g, _.vz(b.get("url")))
        });
        _.M(this.C, "passivelogo_changed", function() {
            return Ewa(d)
        });
        Ewa(this)
    };
    Fwa = function(a, b) {
        _.nG(a.h, b ? _.Nr["google_logo_white.svg"] : _.Nr["google_logo_color.svg"])
    };
    Ewa = function(a) {
        a.D && a.C.get("passiveLogo") ? a.j.contains(a.g) ? a.j.replaceChild(a.o, a.g) : a.j.appendChild(a.o) : (a.g.appendChild(a.o), a.j.appendChild(a.g))
    };
    Gwa = function(a, b, c) {
        function d() {
            var g = f.get("hasCustomStyles"),
                h = a.getMapTypeId();
            Fwa(e, g || "satellite" === h || "hybrid" === h)
        }
        var e = new jI(a, b, c),
            f = a.__gm;
        _.M(f, "hascustomstyles_changed", d);
        _.M(a, "maptypeid_changed", d);
        d();
        return e
    };
    Hwa = function(a, b, c, d) {
        function e() {
            0 != f.get("enabled") && (null != d && f.get("active") ? f.set("value", d) : f.set("value", c))
        }
        var f = this;
        _.M(this, "value_changed", function() {
            f.set("active", f.get("value") == c)
        });
        new _.Ti(a, b, e);
        "click" == b && "button" != a.tagName.toLowerCase() && new _.Ti(a, "keydown", function(g) {
            "Enter" != g.key && " " != g.key || e()
        });
        _.M(this, "display_changed", function() {
            _.eA(a, 0 != f.get("display"))
        })
    };
    kI = function(a, b, c, d) {
        return new Hwa(a, b, c, d)
    };
    mI = function(a, b, c, d, e) {
        var f = this;
        this.g = _.Mr(d.title);
        if (this.o = d.Ku || !1) this.g.setAttribute("role", "menuitemradio"), this.g.setAttribute("aria-checked", !1);
        _.Wi(this.g);
        a.appendChild(this.g);
        _.lz(this.g);
        this.h = this.g.style;
        this.h.overflow = "hidden";
        d.hq ? FH(this.g) : this.h.textAlign = "center";
        d.height && (this.h.height = _.jn(d.height), this.h.display = "table-cell", this.h.verticalAlign = "middle");
        this.h.position = "relative";
        KH(this.g, d);
        d.Yn && Vva(this.g);
        d.fr && Wva(this.g);
        this.g.style.webkitBackgroundClip =
            "padding-box";
        this.g.style.backgroundClip = "padding-box";
        this.g.style.MozBackgroundClip = "padding";
        this.C = d.Gs || !1;
        this.D = d.Yn || !1;
        _.jA(this.g, "0 1px 4px -1px rgba(0,0,0,0.3)");
        d.oB ? (a = document.createElement("span"), a.style.position = "relative", _.$n(a, new _.R(3, 0), !_.tw.Tb(), !0), a.appendChild(b), this.g.appendChild(a), b = _.mG(_.Nk("arrow-down"), this.g), _.$n(b, new _.R(8, 0), !_.tw.Tb()), b.style.top = "50%", b.style.marginTop = _.jn(-2), this.set("active", !1), this.g.setAttribute("aria-haspopup", "true"), this.g.setAttribute("aria-expanded",
            "false")) : (this.g.appendChild(b), b = e(this.g, "click", c), b.bindTo("value", this), this.bindTo("active", b), b.bindTo("enabled", this));
        d.QA && this.g.setAttribute("aria-haspopup", "true");
        d.Gs && (this.h.fontWeight = "500");
        this.j = _.Yd(this.h.paddingLeft) || 0;
        d.hq || (this.h.fontWeight = "500", d = this.g.offsetWidth - this.j - (_.Yd(this.h.paddingRight) || 0), this.h.fontWeight = "", _.Wd(d) && 0 <= d && (this.h.minWidth = _.jn(d)));
        new _.Ti(this.g, "click", function(g) {
            !1 !== f.get("enabled") && _.N(f, "click", g)
        });
        new _.Ti(this.g, "keydown",
            function(g) {
                !1 !== f.get("enabled") && _.N(f, "keydown", g)
            });
        new _.Ti(this.g, "blur", function(g) {
            !1 !== f.get("enabled") && _.N(f, "blur", g)
        });
        new _.Ti(this.g, "mouseover", function() {
            return lI(f, !0)
        });
        new _.Ti(this.g, "mouseout", function() {
            return lI(f, !1)
        });
        _.M(this, "enabled_changed", function() {
            return lI(f, !1)
        });
        _.M(this, "active_changed", function() {
            return lI(f, !1)
        })
    };
    lI = function(a, b) {
        var c = !!a.get("active") || a.C;
        0 == a.get("enabled") ? (a.h.color = "gray", b = c = !1) : (a.h.color = c || b ? "#000" : "#565656", a.o && a.g.setAttribute("aria-checked", c));
        a.D || (a.h.borderLeft = "0");
        _.Wd(a.j) && (a.h.paddingLeft = _.jn(a.j));
        a.h.fontWeight = c ? "500" : "";
        a.h.backgroundColor = b ? "#ebebeb" : "#fff"
    };
    _.nI = function(a, b, c, d) {
        return new mI(a, b, c, d, kI)
    };
    oI = function(a, b, c, d, e) {
        this.g = _.ao("li", a);
        this.g.tabIndex = -1;
        this.g.setAttribute("role", "menuitemcheckbox");
        this.g.setAttribute("aria-label", b);
        _.Wi(this.g);
        this.h = document.createElement("span");
        this.h.style["mask-image"] = 'url("' + _.Nr["checkbox_checked.svg"] + '")';
        this.h.style["-webkit-mask-image"] = 'url("' + _.Nr["checkbox_checked.svg"] + '")';
        this.j = document.createElement("span");
        this.j.style["mask-image"] = 'url("' + _.Nr["checkbox_empty.svg"] + '")';
        this.j.style["-webkit-mask-image"] = 'url("' + _.Nr["checkbox_empty.svg"] +
            '")';
        a = _.ao("span", this.g);
        a.appendChild(this.h);
        a.appendChild(this.j);
        this.o = _.ao("label", this.g);
        this.o.textContent = b;
        KH(this.g, e);
        b = _.tw.Tb();
        _.lz(this.g);
        FH(this.g);
        this.j.style.height = this.h.style.height = "1em";
        this.j.style.width = this.h.style.width = "1em";
        this.j.style.transform = this.h.style.transform = "translateY(0.15em)";
        this.o.style.cursor = "inherit";
        this.g.style.backgroundColor = "#fff";
        this.g.style.whiteSpace = "nowrap";
        this.g.style[b ? "paddingLeft" : "paddingRight"] = _.jn(8);
        Iwa(this, c, d);
        _.Nm(Jwa,
            this.g);
        _.zm(this.g, "checkbox-menu-item")
    };
    Iwa = function(a, b, c) {
        _.on(a, "active_changed", function() {
            var d = !!a.get("active");
            _.eA(a.h, d);
            _.eA(a.j, !d);
            a.g.setAttribute("aria-checked", d)
        });
        _.mf(a.g, "mouseover", function() {
            Kwa(a, !0)
        });
        _.mf(a.g, "mouseout", function() {
            Kwa(a, !1)
        });
        b = kI(a.g, "click", b, c);
        b.bindTo("value", a);
        b.bindTo("display", a);
        a.bindTo("active", b)
    };
    Kwa = function(a, b) {
        a.g.style.backgroundColor = b ? "#ebebeb" : "#fff"
    };
    pI = function(a, b, c, d) {
        var e = this.g = _.ao("li", a);
        KH(e, d);
        _.Xn(b, e);
        e.style.backgroundColor = "#fff";
        e.tabIndex = -1;
        e.setAttribute("role", "menuitemradio");
        e.setAttribute("aria-checked", !1);
        _.Wi(e);
        _.of(this, "active_changed", this, function() {
            var f = this.get("active") || !1;
            e.style.fontWeight = f ? "500" : "";
            e.setAttribute("aria-checked", f)
        });
        _.of(this, "enabled_changed", this, function() {
            var f = 0 != this.get("enabled");
            e.style.color = f ? "black" : "gray";
            (f = f ? d.title : d.rz) && e.setAttribute("title", f)
        });
        a = kI(e, "click", c);
        a.bindTo("value",
            this);
        a.bindTo("display", this);
        a.bindTo("enabled", this);
        this.bindTo("active", a);
        _.nn(e, "mouseover", this, function() {
            0 != this.get("enabled") && (e.style.backgroundColor = "#ebebeb", e.style.color = "#000")
        });
        _.mf(e, "mouseout", function() {
            e.style.backgroundColor = "#fff";
            e.style.color = "#565656"
        })
    };
    Lwa = function(a) {
        var b = _.ao("div", a);
        b.style.margin = "1px 0";
        b.style.borderTop = "1px solid #ebebeb";
        a = this.get("display");
        b && (b.setAttribute("aria-hidden", "true"), b.style.visibility = b.style.visibility || "inherit", b.style.display = a ? "" : "none");
        _.of(this, "display_changed", this, function() {
            _.eA(b, 0 != this.get("display"))
        })
    };
    qI = function(a, b, c, d, e, f) {
        f = f || {};
        this.F = a;
        this.C = b;
        a = this.g = _.ao("ul", b);
        a.style.backgroundColor = "white";
        a.style.listStyle = "none";
        a.style.margin = a.style.padding = 0;
        _.bo(a, -1);
        a.style.padding = _.jn(2);
        Uva(a, _.jn(_.MC(d)));
        _.jA(a, "0 1px 4px -1px rgba(0,0,0,0.3)");
        f.position ? _.$n(a, f.position, f.dD) : (a.style.position = "absolute", a.style.top = "100%", a.style.left = "0", a.style.right = "0");
        FH(a);
        _.fA(a);
        this.j = [];
        this.h = null;
        this.o = e;
        e = this.o.id || (this.o.id = _.Bk());
        a.setAttribute("role", "menu");
        for (a.setAttribute("aria-labelledby",
                e); _.Pd(c);) {
            e = c.shift();
            f = _.A(e);
            for (b = f.next(); !b.done; b = f.next()) {
                b = b.value;
                var g = void 0,
                    h = {
                        title: b.alt,
                        rz: b.o || void 0,
                        fontSize: NH(d),
                        padding: [1 + d >> 3]
                    };
                null != b.j ? g = new oI(a, b.label, b.g, b.j, h) : g = new pI(a, b.label, b.g, h);
                g.bindTo("value", this.F, b.Ff);
                g.bindTo("display", b);
                g.bindTo("enabled", b);
                this.j.push(g)
            }
            f = _.u(c, "flat").call(c);
            f.length && (b = new Lwa(a), Mwa(b, e, f))
        }
    };
    Mwa = function(a, b, c) {
        function d() {
            function e(f) {
                f = _.A(f);
                for (var g = f.next(); !g.done; g = f.next())
                    if (0 != g.value.get("display")) return !0;
                return !1
            }
            a.set("display", e(b) && e(c))
        }
        _.mb(b.concat(c), function(e) {
            _.M(e, "display_changed", d)
        })
    };
    Pwa = function(a) {
        var b = a.g;
        if (!b.g) {
            var c = a.C;
            b.g = [_.mf(c, "mouseout", function() {
                b.timeout = window.setTimeout(function() {
                    a.set("active", !1)
                }, 1E3)
            }), _.nn(c, "mouseover", a, a.D), _.mf(document.body, "click", function(e) {
                for (e = e.target; e;) {
                    if (e == c) return;
                    e = e.parentNode
                }
                a.set("active", !1)
            }), _.mf(b, "keydown", function(e) {
                return Nwa(a, e)
            }), _.mf(b, "blur", function() {
                setTimeout(function() {
                    b.contains(document.activeElement) || a.set("active", !1)
                }, 0)
            }, !0)]
        }
        _.gA(b);
        if (a.C.contains(document.activeElement)) {
            var d = _.u(a.j,
                "find").call(a.j, function(e) {
                return !1 !== e.get("display")
            });
            d && Owa(a, d)
        }
    };
    Nwa = function(a, b) {
        if ("Escape" === b.key || "Esc" === b.key) a.set("active", !1);
        else {
            var c = a.j.filter(function(e) {
                    return !1 !== e.get("display")
                }),
                d = a.h ? c.indexOf(a.h) : 0;
            if ("ArrowUp" === b.key) d--;
            else if ("ArrowDown" === b.key) d++;
            else if ("Home" === b.key) d = 0;
            else if ("End" === b.key) d = c.length - 1;
            else return;
            d = (d + c.length) % c.length;
            Owa(a, c[d])
        }
    };
    Owa = function(a, b) {
        a.h = b;
        b.ob().focus()
    };
    Swa = function(a, b, c, d) {
        var e = this;
        this.g = a;
        this.g.setAttribute("role", "menubar");
        this.j = d;
        this.h = [];
        _.M(this, "fontloaded_changed", function() {
            if (e.get("fontLoaded")) {
                for (var h = e.h.length, k = 0, l = 0; l < h; ++l) {
                    var m = _.hj(e.h[l].parentNode),
                        p = l == h - 1;
                    e.h[l].Xt && _.$n(e.h[l].Xt.g, new _.R(p ? 0 : k, m.height), p);
                    k += m.width
                }
                e.h.length = 0
            }
        });
        _.M(this, "mapsize_changed", function() {
            return Qwa(e)
        });
        _.M(this, "display_changed", function() {
            return Qwa(e)
        });
        d = b.length;
        for (var f = 0, g = 0; g < d; ++g) f = Rwa(this, c, b[g], f, 0 == g, g == d - 1);
        _.BA();
        a.style.cursor = "pointer"
    };
    Rwa = function(a, b, c, d, e, f) {
        var g = document.createElement("div");
        a.g.appendChild(g);
        _.Sva(g);
        _.Nm(Twa, a.g);
        _.Jn(g, "gm-style-mtc");
        var h = _.Xn(c.label, a.g, !0);
        b = b(g, h, c.g, {
            title: c.alt,
            padding: [0, 17],
            height: a.j,
            fontSize: NH(a.j),
            Yn: e,
            fr: f,
            Ku: !0,
            QA: !0
        });
        g.style.position = "relative";
        e = b.ob();
        new _.Ti(e, "focusin", function() {
            g.style.zIndex = 1
        });
        new _.Ti(e, "focusout", function() {
            g.style.zIndex = 0
        });
        c.Ff && b.bindTo("value", a, c.Ff);
        e = null;
        h = _.hj(g);
        c.h && (e = new qI(a, g, c.h, a.j, b.ob(), {
            position: new _.R(f ? 0 : d, h.height),
            dD: f
        }), Uwa(g, b, e));
        a.h.push({
            parentNode: g,
            Xt: e
        });
        return d += h.width
    };
    Qwa = function(a) {
        var b = a.get("mapSize");
        b = !!(a.get("display") || b && 200 <= b.width && 200 <= b.height);
        _.eA(a.g, b);
        _.N(a.g, "resize")
    };
    Uwa = function(a, b, c) {
        new _.Ti(a, "click", function() {
            return c.set("active", !0)
        });
        new _.Ti(a, "mouseover", function() {
            b.get("active") && c.set("active", !0)
        });
        _.mf(b, "active_changed", function() {
            b.get("active") || c.set("active", !1)
        });
        _.M(b, "keydown", function(d) {
            "ArrowDown" !== d.key && "ArrowUp" !== d.key || c.set("active", !0)
        });
        _.M(b, "click", function(d) {
            var e = _.kA(d) ? 164753 : 164752;
            _.Q(window, _.kA(d) ? "Mtcmi" : "Mtcki");
            _.P(window, e)
        })
    };
    rI = function(a, b, c) {
        var d = this;
        _.BA();
        a.style.cursor = "pointer";
        FH(a);
        a.style.width = _.jn(120);
        _.Nm(Twa, document.head);
        _.Jn(a, "gm-style-mtc");
        var e = _.Xn("", a, !0),
            f = _.nI(a, e, null, {
                title: "Thay \u0111\u1ed5i ki\u1ec3u b\u1ea3n \u0111\u1ed3",
                oB: !0,
                hq: !0,
                Gs: !0,
                padding: [8, 17],
                fontSize: 18,
                Yn: !0,
                fr: !0
            }),
            g = {},
            h = [b];
        b = _.A(b);
        for (var k = b.next(); !k.done; k = b.next()) k = k.value, "mapTypeId" == k.Ff && (g[k.g] = k.label), k.h && h.push.apply(h, _.oa(k.h));
        this.addListener("maptypeid_changed", function() {
            var m = g[d.get("mapTypeId")] ||
                "";
            e.textContent = m
        });
        var l = f.ob();
        this.g = new qI(this, a, h, c, l);
        f.addListener("click", function(m) {
            d.g.set("active", !d.g.get("active"));
            var p = _.kA(m) ? 164753 : 164752;
            _.Q(window, _.kA(m) ? "Mtcmi" : "Mtcki");
            _.P(window, p)
        });
        f.addListener("keydown", function(m) {
            "ArrowDown" !== m.key && "ArrowUp" !== m.key || d.g.set("active", !0)
        });
        this.g.addListener("active_changed", function() {
            l.setAttribute("aria-expanded", !!d.g.get("active"))
        });
        this.h = a
    };
    Vwa = function(a) {
        var b = a.get("mapSize");
        b = !!(a.get("display") || b && 200 <= b.width && 200 <= b.height);
        _.eA(a.h, b);
        _.N(a.h, "resize")
    };
    sI = function(a) {
        this.g = !1;
        this.map = a
    };
    tI = function(a, b, c) {
        a.get(b) !== c && (a.g = !0, a.set(b, c), a.g = !1)
    };
    uI = function(a, b, c) {
        this.h = a;
        this.j = _.bI(a, b.getDiv());
        this.F = Wwa();
        _.fA(a);
        this.g = Xwa(this.j);
        _.mf(this.g, "click", function(d) {
            _.qn(b, "Rc");
            _.pn(161529);
            var e = _.kA(d) ? 165226 : 165225;
            _.Q(window, _.kA(d) ? "Rmimi" : "Rmiki");
            _.P(window, e)
        });
        this.o = b;
        this.C = "";
        this.D = c
    };
    Ywa = function(a, b) {
        b ? (a.style.fontFamily = "Arial,sans-serif", a.style.fontSize = "85%", a.style.fontWeight = "bold", a.style.bottom = "1px", a.style.padding = "1px 3px") : (a.style.fontFamily = "Roboto,Arial,sans-serif", a.style.fontSize = _.jn(10));
        a.style.color = "#000000";
        a.style.textDecoration = "none";
        a.style.position = "relative"
    };
    Xwa = function(a) {
        var b = _.ao("a");
        b.target = "_blank";
        b.rel = "noopener";
        b.title = "B\u00e1o c\u00e1o l\u1ed7i trong b\u1ea3n \u0111\u1ed3 \u0111\u01b0\u1eddng ho\u1eb7c h\u00ecnh \u1ea3nh \u0111\u1ebfn Google";
        Nva(b, "B\u00e1o c\u00e1o l\u1ed7i trong b\u1ea3n \u0111\u1ed3 \u0111\u01b0\u1eddng ho\u1eb7c h\u00ecnh \u1ea3nh \u0111\u1ebfn Google");
        b.textContent = "B\u00e1o c\u00e1o m\u1ed9t l\u1ed7i b\u1ea3n \u0111\u1ed3";
        Ywa(b);
        a.appendChild(b);
        return b
    };
    Wwa = function() {
        var a = new Image;
        a.src = _.Nr["bug_report_icon.svg"];
        a.alt = "";
        a.style.width = "12px";
        return a
    };
    vI = function(a) {
        var b = a.get("available");
        _.N(a.h, "resize");
        a.set("rmiLinkData", b ? {
            label: "B\u00e1o c\u00e1o m\u1ed9t l\u1ed7i b\u1ea3n \u0111\u1ed3",
            tooltip: "B\u00e1o c\u00e1o l\u1ed7i trong b\u1ea3n \u0111\u1ed3 \u0111\u01b0\u1eddng ho\u1eb7c h\u00ecnh \u1ea3nh \u0111\u1ebfn Google",
            url: a.C
        } : void 0)
    };
    Zwa = function(a) {
        var b = a.get("available"),
            c = !1 !== a.get("enabled");
        if (void 0 === b) return !1;
        a = a.get("mapTypeId");
        return b && _.qqa(a) && c && !_.go()
    };
    $wa = function(a, b, c) {
        a.innerText = "";
        b = _.A(b ? [_.Nr["tilt_45_normal.svg"], _.Nr["tilt_45_hover.svg"], _.Nr["tilt_45_active.svg"]] : [_.Nr["tilt_0_normal.svg"], _.Nr["tilt_0_hover.svg"], _.Nr["tilt_0_active.svg"]]);
        for (var d = b.next(); !d.done; d = b.next()) {
            d = d.value;
            var e = document.createElement("img");
            e.alt = "";
            e.style.width = _.jn(NH(c));
            e.src = d;
            a.appendChild(e)
        }
    };
    axa = function(a, b, c) {
        for (var d = _.A([_.Nr["rotate_right_normal.svg"], _.Nr["rotate_right_hover.svg"], _.Nr["rotate_right_active.svg"]]), e = d.next(); !e.done; e = d.next()) {
            e = e.value;
            var f = document.createElement("img"),
                g = _.jn(NH(b) + 2);
            f.alt = "";
            f.style.width = g;
            f.style.height = g;
            f.src = e;
            a.style.transform = c ? "scaleX(-1)" : "";
            a.appendChild(f)
        }
    };
    bxa = function(a) {
        var b = _.ao("div");
        b.style.position = "relative";
        b.style.overflow = "hidden";
        b.style.width = _.jn(3 * a / 4);
        b.style.height = _.jn(1);
        b.style.margin = "0 5px";
        b.style.backgroundColor = "rgb(230, 230, 230)";
        return b
    };
    wI = function(a, b, c) {
        var d = this,
            e = _.$i[43] ? "rgb(34, 34, 34)" : "rgb(255, 255, 255)";
        _.Nm(YH, c);
        this.D = b;
        this.H = a;
        this.g = _.ao("div", a);
        this.g.style.backgroundColor = e;
        _.jA(this.g, "0 1px 4px -1px rgba(0,0,0,0.3)");
        JH(this.g, _.jn(_.MC(b)));
        this.j = _.Mr("Xoay b\u1ea3n \u0111\u1ed3 theo chi\u1ec1u kim \u0111\u1ed3ng h\u1ed3");
        this.j.style.left = "0";
        this.j.style.top = "0";
        this.j.style.overflow = "hidden";
        this.j.setAttribute("class", "gm-control-active");
        _.gj(this.j, new _.Fg(b, b));
        _.eo(this.j);
        axa(this.j, b, !1);
        this.g.appendChild(this.j);
        this.F = bxa(b);
        this.g.appendChild(this.F);
        this.o = _.Mr("Xoay b\u1ea3n \u0111\u1ed3 ng\u01b0\u1ee3c chi\u1ec1u kim \u0111\u1ed3ng h\u1ed3");
        this.o.style.left = "0";
        this.o.style.top = "0";
        this.o.style.overflow = "hidden";
        this.o.setAttribute("class", "gm-control-active");
        _.gj(this.o, new _.Fg(b, b));
        _.eo(this.o);
        axa(this.o, b, !0);
        this.g.appendChild(this.o);
        this.G = bxa(b);
        this.g.appendChild(this.G);
        this.C = _.Mr("Nghi\u00eang b\u1ea3n \u0111\u1ed3");
        this.C.style.left = this.C.style.top = "0";
        this.C.style.overflow = "hidden";
        this.C.setAttribute("class", "gm-tilt gm-control-active");
        $wa(this.C, !1, b);
        _.gj(this.C, new _.Fg(b, b));
        _.eo(this.C);
        this.g.appendChild(this.C);
        this.h = !0;
        this.j.addEventListener("click", function(f) {
            var g = +d.get("heading") || 0;
            d.set("heading", (g + 270) % 360);
            cxa(f)
        });
        this.o.addEventListener("click", function(f) {
            var g = +d.get("heading") || 0;
            d.set("heading", (g + 90) % 360);
            cxa(f)
        });
        this.C.addEventListener("click", function(f) {
            d.h = !d.h;
            d.set("tilt", d.h ? 45 : 0);
            var g = _.kA(f) ? 164824 : 164823;
            _.Q(window, _.kA(f) ? "Tcmi" : "Tcki");
            _.P(window, g)
        });
        _.M(this, "aerialavailableatzoom_changed", function() {
            return d.refresh()
        });
        _.M(this, "tilt_changed", function() {
            d.h = 0 != d.get("tilt");
            d.refresh()
        });
        _.M(this, "mapsize_changed", function() {
            d.refresh()
        });
        _.M(this, "rotatecontrol_changed", function() {
            d.refresh()
        })
    };
    cxa = function(a) {
        var b = _.kA(a) ? 164822 : 164821;
        _.Q(window, _.kA(a) ? "Rcmi" : "Rcki");
        _.P(window, b)
    };
    dxa = function(a, b, c) {
        a = new wI(a, b, c);
        a.bindTo("mapSize", this);
        a.bindTo("rotateControl", this);
        a.bindTo("aerialAvailableAtZoom", this);
        a.bindTo("heading", this);
        a.bindTo("tilt", this)
    };
    fxa = function(a, b, c) {
        var d = this;
        this.fa = a;
        this.h = !1;
        this.o = c;
        c = new _.Ne(9 == b.nodeType ? b : b.ownerDocument || b.document);
        this.C = _.Oe(c, "span");
        c.appendChild(b, this.C);
        this.g = _.Oe(c, "div");
        c.appendChild(b, this.g);
        exa(this, c);
        this.j = !0;
        b = _.Bk();
        c = document.createElement("span");
        c.id = b;
        c.textContent = "Nh\u1ea5p \u0111\u1ec3 chuy\u1ec3n \u0111\u1ed5i gi\u1eefa c\u00e1c \u0111\u01a1n v\u1ecb h\u1ec7 m\u00e9t v\u00e0 h\u1ec7 \u0111o l\u01b0\u1eddng Anh";
        c.style.display = "none";
        a.appendChild(c);
        a.setAttribute("aria-describedby",
            b);
        _.ji(a, "click", function(e) {
            d.j = !d.j;
            xI(d);
            _.kA(e) ? (_.Q(window, "Scmi"), _.P(window, 165091)) : (_.Q(window, "Scki"), _.P(window, 167511))
        });
        _.Am(this.o, function() {
            return xI(d)
        })
    };
    exa = function(a, b) {
        LH(a.g, "position", "relative");
        LH(a.g, "display", "inline-block");
        a.g.style.height = _.FA(8, !0);
        LH(a.g, "bottom", "-1px");
        var c = _.Oe(b, "div");
        b.appendChild(a.g, c);
        _.GA(c, "100%", 4);
        LH(c, "position", "absolute");
        MH(c, 0, 0);
        c = _.Oe(b, "div");
        b.appendChild(a.g, c);
        _.GA(c, 4, 8);
        MH(c, 0, 0);
        LH(c, "backgroundColor", "#fff");
        c = _.Oe(b, "div");
        b.appendChild(a.g, c);
        _.GA(c, 4, 8);
        LH(c, "position", "absolute");
        LH(c, "backgroundColor", "#fff");
        LH(c, "right", "0px");
        LH(c, "bottom", "0px");
        c = _.Oe(b, "div");
        b.appendChild(a.g,
            c);
        LH(c, "position", "absolute");
        LH(c, "backgroundColor", "#666");
        c.style.height = _.FA(2, !0);
        LH(c, "left", "1px");
        LH(c, "bottom", "1px");
        LH(c, "right", "1px");
        c = _.Oe(b, "div");
        b.appendChild(a.g, c);
        LH(c, "position", "absolute");
        _.GA(c, 2, 6);
        MH(c, 1, 1);
        LH(c, "backgroundColor", "#666");
        c = _.Oe(b, "div");
        b.appendChild(a.g, c);
        _.GA(c, 2, 6);
        LH(c, "position", "absolute");
        LH(c, "backgroundColor", "#666");
        LH(c, "bottom", "1px");
        LH(c, "right", "1px")
    };
    xI = function(a) {
        var b = a.o.get();
        b && (b *= 80, b = a.j ? gxa(b / 1E3, b, !0) : gxa(b / 1609.344, 3.28084 * b, !1), a.C.textContent = b.sz + "\u00a0", a.fa.setAttribute("aria-label", b.Ou), a.fa.title = b.Ou, a.g.style.width = _.FA(b.DC + 4, !0), _.N(a.fa, "resize"))
    };
    gxa = function(a, b, c) {
        var d = a,
            e = c ? "km" : "d\u1eb7m";
        1 > a && (d = b, e = c ? "m" : "b\u1ed9");
        for (b = 1; d >= 10 * b;) b *= 10;
        d >= 5 * b && (b *= 5);
        d >= 2 * b && (b *= 2);
        d = Math.round(80 * b / d);
        var f = c ? "T\u1ef7 l\u1ec7 b\u1ea3n \u0111\u1ed3: " + b + " km/" + d + " pixel" : "T\u1ef7 l\u1ec7 b\u1ea3n \u0111\u1ed3: " + b + " d\u1eb7m/" + d + " pixel";
        1 > a && (f = c ? "T\u1ef7 l\u1ec7 b\u1ea3n \u0111\u1ed3: " + b + " m/" + d + " pixel" : "T\u1ef7 l\u1ec7 b\u1ea3n \u0111\u1ed3: " + b + " b\u1ed9/" + d + " pixel");
        return {
            DC: d,
            sz: b + " " + e,
            Ou: f
        }
    };
    ixa = function(a) {
        var b = this;
        this.g = 0;
        this.fa = document.createElement("div");
        this.fa.style.display = "inline-flex";
        this.h = new _.Ii(function() {
            b.update(b.g)
        }, 0);
        this.yi = a.yi;
        this.Ym = hxa(this, a.Ym);
        a = _.A(this.yi);
        for (var c = a.next(); !c.done; c = a.next()) c = c.value, c.Yb(), c = c.Yd(), this.fa.appendChild(c), _.M(c, "resize", function() {
            _.Ji(b.h)
        })
    };
    hxa = function(a, b) {
        return b ? (b.every(function(c) {
            return _.u(a.yi, "includes").call(a.yi, c)
        }), b) : a.yi
    };
    yI = function(a, b, c, d) {
        a.innerText = "";
        b = _.A(0 === b ? 2 === c ? [_.Nr["zoom_in_normal_dark.svg"], _.Nr["zoom_in_hover_dark.svg"], _.Nr["zoom_in_active_dark.svg"], _.Nr["zoom_in_disable_dark.svg"]] : [_.Nr["zoom_in_normal.svg"], _.Nr["zoom_in_hover.svg"], _.Nr["zoom_in_active.svg"], _.Nr["zoom_in_disable.svg"]] : 2 === c ? [_.Nr["zoom_out_normal_dark.svg"], _.Nr["zoom_out_hover_dark.svg"], _.Nr["zoom_out_active_dark.svg"], _.Nr["zoom_out_disable_dark.svg"]] : [_.Nr["zoom_out_normal.svg"], _.Nr["zoom_out_hover.svg"], _.Nr["zoom_out_active.svg"],
            _.Nr["zoom_out_disable.svg"]
        ]);
        for (c = b.next(); !c.done; c = b.next()) {
            c = c.value;
            var e = document.createElement("img");
            e.style.width = e.style.height = _.jn(NH(d));
            e.src = c;
            e.alt = "";
            a.appendChild(e)
        }
    };
    AI = function(a, b, c, d) {
        var e = this;
        this.o = a;
        this.h = b;
        this.g = _.ao("div", a);
        _.eo(this.g);
        _.co(this.g);
        _.jA(this.g, "0 1px 4px -1px rgba(0,0,0,0.3)");
        JH(this.g, _.jn(_.MC(b)));
        this.g.style.cursor = "pointer";
        _.Nm(YH, d);
        _.mf(this.g, "mouseover", function() {
            e.set("mouseover", !0)
        });
        _.mf(this.g, "mouseout", function() {
            e.set("mouseover", !1)
        });
        this.C = jxa(this, this.g, 0);
        this.j = _.ao("div", this.g);
        this.j.style.position = "relative";
        this.j.style.overflow = "hidden";
        this.j.style.width = _.jn(3 * b / 4);
        this.j.style.height = _.jn(1);
        this.j.style.margin = "0 5px";
        this.D = jxa(this, this.g, 1);
        _.M(this, "display_changed", function() {
            return kxa(e)
        });
        _.M(this, "mapsize_changed", function() {
            return kxa(e)
        });
        _.M(this, "maptypeid_changed", function() {
            var f = e.get("mapTypeId");
            e.set("controlStyle", ("satellite" === f || "hybrid" === f) && _.$i[43] || "streetview" == f ? 2 : 1)
        });
        _.M(this, "controlstyle_changed", function() {
            var f = e.get("controlStyle");
            if (null != f) {
                var g = zI[f];
                yI(e.C, 0, f, e.h);
                yI(e.D, 1, f, e.h);
                e.g.style.backgroundColor = g.backgroundColor;
                e.j.style.backgroundColor =
                    g.St
            }
        })
    };
    jxa = function(a, b, c) {
        var d = _.Mr(0 === c ? "Ph\u00f3ng to" : "Thu nh\u1ecf");
        b.appendChild(d);
        _.mf(d, "click", function(e) {
            var f = 0 === c ? 1 : -1;
            a.set("zoom", a.get("zoom") + f);
            f = _.kA(e) ? 164935 : 164934;
            _.Q(window, _.kA(e) ? "Zcmi" : "Zcki");
            _.P(window, f)
        });
        d.setAttribute("class", "gm-control-active");
        d.style.overflow = "hidden";
        b = a.get("controlStyle");
        yI(d, c, b, a.h);
        return d
    };
    kxa = function(a) {
        var b = a.get("mapSize");
        if (b && 200 <= b.width && 200 <= b.height || a.get("display")) {
            _.gA(a.o);
            b = a.h;
            var c = 2 * a.h + 1;
            a.g.style.width = _.jn(b);
            a.g.style.height = _.jn(c);
            a.o.dataset.controlWidth = String(b);
            a.o.dataset.controlHeight = String(c);
            _.N(a.o, "resize");
            b = a.C.style;
            b.width = _.jn(a.h);
            b.height = _.jn(a.h);
            b.left = b.top = "0";
            a.j.style.top = "0";
            b = a.D.style;
            b.width = _.jn(a.h);
            b.height = _.jn(a.h);
            b.left = b.top = "0"
        } else _.fA(a.o)
    };
    BI = function(a, b, c, d) {
        a = this.g = _.ao("div");
        _.IH(a);
        b = new AI(a, b, c, d);
        b.bindTo("mapSize", this);
        b.bindTo("display", this, "display");
        b.bindTo("mapTypeId", this);
        b.bindTo("zoom", this);
        b.bindTo("zoomRange", this);
        this.rm = b
    };
    lxa = function(a) {
        a.rm && (a.rm.unbindAll(), a.rm = null)
    };
    DI = function(a, b, c) {
        _.IH(a);
        _.bo(a, 1000001);
        this.g = a;
        a = _.ao("div", a);
        b = _.bI(a, b);
        this.C = a;
        a = _.Mr("D\u1eef li\u1ec7u B\u1ea3n \u0111\u1ed3");
        b.appendChild(a);
        a.textContent = "D\u1eef li\u1ec7u B\u1ea3n \u0111\u1ed3";
        a.style.color = "#000000";
        a.style.display = "inline-block";
        a.style.fontFamily = "inherit";
        a.style.lineHeight = "inherit";
        _.cA(a, "click", this);
        this.j = a;
        b = _.ao("span", b);
        b.style.display = "none";
        this.h = b;
        this.o = c;
        CI(this)
    };
    CI = function(a) {
        var b = a.get("attributionText") || "H\u00ecnh \u1ea3nh c\u00f3 th\u1ec3 c\u00f3 b\u1ea3n quy\u1ec1n";
        a.o && (b = b.replace("Map data", "Map Data"));
        _.lA(a.h, b);
        _.N(a.g, "resize")
    };
    EI = function(a) {
        this.j = a.ownerElement;
        this.h = document.createElement("div");
        this.h.style.color = "#222";
        this.h.style.maxWidth = "280px";
        this.g = new _.Sr({
            content: this.h,
            ue: a.ue,
            bd: a.bd,
            ownerElement: this.j,
            title: "D\u1eef li\u1ec7u B\u1ea3n \u0111\u1ed3"
        });
        _.zm(this.g.element, "copyright-dialog-view")
    };
    FI = function(a) {
        _.HH(a, "gmnoprint");
        _.Jn(a, "gmnoscreen");
        this.g = a;
        a = this.h = _.ao("div", a);
        a.style.fontFamily = "Roboto,Arial,sans-serif";
        a.style.fontSize = _.jn(11);
        a.style.color = "#000000";
        a.style.direction = "ltr";
        a.style.textAlign = "right";
        a.style.backgroundColor = "#f5f5f5"
    };
    GI = function(a, b) {
        _.IH(a);
        _.bo(a, 1000001);
        this.g = a;
        this.h = _.bI(a, b);
        this.j = a = _.ao("a", this.h);
        a.style.textDecoration = "none";
        a.style.cursor = "pointer";
        a.textContent = "\u0110i\u1ec1u kho\u1ea3n s\u1eed d\u1ee5ng";
        Pva(a, _.mla);
        a.target = "_blank";
        a.setAttribute("rel", "noopener");
        a.style.color = "#000000";
        a.addEventListener("click", function(c) {
            var d = _.kA(c) ? 165234 : 165233;
            _.Q(window, _.kA(c) ? "Tscmi" : "Tscki");
            _.P(window, d)
        })
    };
    mxa = function(a, b, c, d) {
        var e = c instanceof _.ih;
        e = new eI(_.ao("div"), a, e ? 2 : 1);
        e.bindTo("keyboardShortcutsShown", this);
        e.bindTo("fontLoaded", this);
        d = new DI(document.createElement("div"), a, d);
        d.bindTo("attributionText", this);
        d.bindTo("fontLoaded", this);
        d.bindTo("isCustomPanorama", this);
        var f = c.__gm.get("innerContainer"),
            g = new EI({
                bd: a,
                ue: function() {
                    _.ho(f).catch(function() {})
                },
                ownerElement: b
            });
        g.bindTo("attributionText", this);
        _.M(d, "click", function(h) {
            g.set("visible", !0);
            var k = _.kA(h) ? 165049 : 165048;
            _.Q(window,
                _.kA(h) ? "Ccmi" : "Ccki");
            _.P(window, k)
        });
        b = new FI(document.createElement("div"));
        b.bindTo("attributionText", this);
        a = new GI(document.createElement("div"), a);
        a.bindTo("fontLoaded", this);
        a.bindTo("mapTypeId", this);
        d.bindTo("mapTypeId", this);
        c && _.$i[28] ? (d.bindTo("hidden", c, "hideLegalNotices"), b.bindTo("hidden", c, "hideLegalNotices"), a.bindTo("hidden", c, "hideLegalNotices")) : (d.bindTo("isCustomPanorama", this), b.bindTo("hidden", this, "isCustomPanorama"));
        this.h = d;
        this.j = b;
        this.o = a;
        this.g = e
    };
    HI = function(a) {
        this.g = a
    };
    II = function(a, b) {
        this.g = b;
        this.h = [];
        _.eo(a);
        _.co(a);
        a.style.fontFamily = "Roboto,Arial,sans-serif";
        a.style.fontSize = _.jn(Math.round(11 * b / 40));
        a.style.textAlign = "center";
        _.jA(a, "rgba(0, 0, 0, 0.3) 0px 1px 4px -1px");
        a.dataset.controlWidth = String(b);
        a.style.cursor = "pointer";
        this.fa = a
    };
    nxa = function(a, b, c) {
        _.mf(b, "mouseover", function() {
            b.style.color = "#bbb";
            b.style.fontWeight = "bold"
        });
        _.mf(b, "mouseout", function() {
            b.style.color = "#999";
            b.style.fontWeight = "400"
        });
        _.nn(b, "click", a, function(d) {
            a.set("pano", c);
            var e = _.kA(d) ? 171224 : 171223;
            _.Q(window, _.kA(d) ? "Ecmi" : "Ecki");
            _.P(window, e)
        })
    };
    JI = function(a, b) {
        var c = this;
        this.fa = a;
        this.g = b;
        this.visible = !0;
        a.classList.add("gm-svpc");
        a.setAttribute("dir", "ltr");
        a.style.background = "#fff";
        b = 32 > this.g ? this.g - 2 : 40 > this.g ? 30 : 10 + this.g / 2;
        this.j = {
            Yp: oxa(b),
            active: pxa(b),
            Xp: qxa(b)
        };
        rxa(this);
        this.set("position", _.CH.xv.offset);
        _.nn(a, "mouseover", this, this.o);
        _.nn(a, "mouseout", this, this.C);
        this.h = new _.AG(a);
        this.h.bindTo("position", this);
        _.qf(this.h, "dragstart", this);
        _.qf(this.h, "drag", this);
        _.qf(this.h, "dragend", this);
        _.M(this.h, "dragend", function() {
            c.set("position",
                _.CH.xv.offset);
            _.Q(window, "Pcmi");
            _.P(window, 165115)
        });
        _.M(this, "mode_changed", function() {
            var d = c.get("mode");
            c.h && !c.h.get("enabled") && c.h.set("enabled", !0);
            sxa(c, d)
        });
        _.M(this, "display_changed", function() {
            txa(c)
        });
        _.M(this, "mapsize_changed", function() {
            txa(c)
        });
        this.set("mode", 1)
    };
    rxa = function(a) {
        for (var b = _.A(_.u(Object, "values").call(Object, a.j)), c = b.next(); !c.done; c = b.next()) c = c.value, c.parentNode && c.parentNode.removeChild(c);
        b = a.fa;
        if (a.visible) {
            b.style.display = "";
            c = new _.Fg(a.g, a.g);
            _.jA(b, "0 1px 4px -1px rgba(0,0,0,0.3)");
            JH(b, _.jn(40 < a.g ? Math.round(a.g / 20) : 2));
            b.style.width = _.jn(c.width);
            b.style.height = _.jn(c.height);
            var d = document.createElement("div");
            b.appendChild(d);
            d.style.position = "absolute";
            d.style.left = "50%";
            d.style.top = "50%";
            d.append(a.j.Yp, a.j.active, a.j.Xp);
            b.dataset.controlWidth = String(c.width);
            b.dataset.controlHeight = String(c.height);
            _.N(b, "resize");
            sxa(a, a.get("mode"))
        } else b.style.display = "none", _.N(b, "resize")
    };
    oxa = function(a) {
        var b = document.createElement("img");
        b.src = _.Nr["pegman_dock_normal.svg"];
        b.style.width = b.style.height = _.jn(a);
        b.style.position = "absolute";
        b.style.transform = "translate(-50%, -50%)";
        b.alt = "Ki\u1ec3m so\u00e1t ng\u01b0\u1eddi h\u00ecnh m\u1eafc \u00e1o trong ch\u1ebf \u0111\u1ed9 xem ph\u1ed1";
        b.style.pointerEvents = "none";
        return b
    };
    pxa = function(a) {
        var b = document.createElement("img");
        b.src = _.Nr["pegman_dock_active.svg"];
        b.style.display = "none";
        b.style.width = b.style.height = _.jn(a);
        b.style.position = "absolute";
        b.style.transform = "translate(-50%, -50%)";
        b.alt = "Ng\u01b0\u1eddi h\u00ecnh m\u1eafc \u00e1o \u1edf \u0111\u1ea7u B\u1ea3n \u0111\u1ed3";
        b.style.pointerEvents = "none";
        return b
    };
    qxa = function(a) {
        var b = document.createElement("img");
        b.style.display = "none";
        b.style.width = b.style.height = _.jn(4 * a / 3);
        b.style.position = "absolute";
        b.style.transform = "translate(-60%, -45%)";
        b.style.pointerEvents = "none";
        b.alt = "Ki\u1ec3m so\u00e1t ng\u01b0\u1eddi h\u00ecnh m\u1eafc \u00e1o trong ch\u1ebf \u0111\u1ed9 xem ph\u1ed1";
        b.src = _.Nr["pegman_dock_hover.svg"];
        return b
    };
    sxa = function(a, b) {
        a.visible && (a = a.j, a.Yp.style.display = a.Xp.style.display = a.active.style.display = "none", 1 === b ? a.Yp.style.display = "" : 2 === b ? a.Xp.style.display = "" : a.active.style.display = "")
    };
    txa = function(a) {
        var b = a.get("mapSize");
        b = !!a.get("display") || !!(b && 200 <= b.width && b && 200 <= b.height);
        a.visible != b && (a.visible = b, rxa(a))
    };
    KI = function(a) {
        var b = this;
        this.o = 0;
        this.G = this.D = -1;
        this.j = 0;
        this.C = this.F = null;
        a = {
            clickable: !1,
            crossOnDrag: !1,
            draggable: !0,
            map: a,
            mapOnly: !0,
            pegmanMarker: !0,
            zIndex: 1E6
        };
        this.M = _.CH.zh;
        this.O = _.CH.eD;
        this.h = _.$f("mode");
        this.g = _.ag("mode");
        this.J = uxa(a);
        var c = new _.jh(a);
        this.nq = c;
        var d = new _.jh(a);
        this.H = d;
        this.g(1);
        this.set("heading", 0);
        c.bindTo("icon", this, "lilypadIcon");
        _.M(this, "position_changed", function() {
            c.set("position", b.get("position"))
        });
        c.bindTo("dragging", this);
        d.set("cursor", _.Sv);
        d.set("icon",
            $va(this.O, 0));
        _.M(this, "dragposition_changed", function() {
            d.set("position", b.get("dragPosition"))
        });
        d.bindTo("dragging", this);
        _.M(this, "dragstart", this.ff);
        _.M(this, "drag", this.og);
        _.M(this, "dragend", this.Gf);
        vxa(this)
    };
    uxa = function(a) {
        return new _.w.Promise(function(b) {
            var c;
            return _.Ca(function(d) {
                if (1 == d.g) return _.va(d, _.Te("marker"), 2);
                c = new _.jh(a);
                c.setDraggable(!0);
                b(c);
                _.wa(d)
            })
        })
    };
    vxa = function(a) {
        var b;
        _.Ca(function(c) {
            if (1 == c.g) return _.va(c, a.J, 2);
            b = c.h;
            b.bindTo("icon", a, "pegmanIcon");
            b.bindTo("position", a, "dragPosition");
            b.bindTo("dragging", a);
            _.qf(b, "dragstart", a);
            _.qf(b, "drag", a);
            _.qf(b, "dragend", a);
            _.wa(c)
        })
    };
    yxa = function(a) {
        var b, c, d;
        return _.Ca(function(e) {
            if (1 == e.g) return b = a.h(), c = _.sG(b), _.va(e, a.J, 2);
            d = e.h;
            d.setVisible(c || 7 === b);
            var f = a.set;
            if (c) {
                var g = a.h() - 3;
                g = $va(a.M, g)
            } else 7 === b ? (g = wxa(a), a.G !== g && (a.G = g, a.F = {
                url: xxa[g],
                scaledSize: new _.Fg(49, 52),
                anchor: new _.R(25, 35)
            }), g = a.F) : g = void 0;
            f.call(a, "pegmanIcon", g);
            _.wa(e)
        })
    };
    zxa = function(a) {
        a.nq.setVisible(!1);
        a.H.setVisible(_.sG(a.h()))
    };
    wxa = function(a) {
        (a = _.Yd(a.get("heading")) % 360) || (a = 0);
        0 > a && (a += 360);
        return Math.round(a / 360 * 16) % 16
    };
    LI = function(a, b, c, d, e, f, g, h, k, l) {
        this.map = a;
        this.H = d;
        this.D = e;
        this.config = f;
        this.ka = g;
        this.controlSize = h;
        this.C = this.j = !1;
        this.h = this.g = this.F = null;
        this.G = _.$f("mode");
        this.o = _.ag("mode");
        this.Jg = l || null;
        this.o(1);
        this.marker = new KI(this.map);
        Axa(this, c, b);
        this.overlay = new _.CG(k);
        k || (this.overlay.bindTo("mapHeading", this), this.overlay.bindTo("tilt", this));
        this.overlay.bindTo("client", this);
        this.overlay.bindTo("client", a, "svClient");
        this.offset = _.FG(c, d)
    };
    Axa = function(a, b, c) {
        var d = a.map.__gm,
            e = new JI(b, a.controlSize, function(h) {
                a.marker.kk(h)
            }, function(h) {
                a.marker.lk(h)
            });
        e.bindTo("mode", a);
        e.bindTo("mapSize", a);
        e.bindTo("display", a);
        a.marker.bindTo("mode", a);
        a.marker.bindTo("dragPosition", a);
        a.marker.bindTo("position", a);
        var f = new _.rG(["mapHeading", "streetviewHeading"], "heading", Bxa);
        f.bindTo("streetviewHeading", a, "heading");
        f.bindTo("mapHeading", a.map, "heading");
        a.marker.bindTo("heading", f);
        a.bindTo("pegmanDragging", a.marker, "dragging");
        d.bindTo("pegmanDragging",
            a);
        _.of(e, "dragstart", a, function() {
            a.offset = _.FG(b, a.H);
            Cxa(a)
        });
        d = {};
        f = _.A(["dragstart", "drag", "dragend"]);
        for (var g = f.next(); !g.done; d = {
                tm: d.tm
            }, g = f.next()) d.tm = g.value, _.M(e, d.tm, function(h) {
            return function() {
                _.N(a.marker, h.tm, {
                    latLng: a.marker.get("position"),
                    pixel: e.get("position")
                })
            }
        }(d));
        _.M(e, "position_changed", function() {
            var h = e.get("position");
            (h = c({
                clientX: h.x + a.offset.x,
                clientY: h.y + a.offset.y
            })) && a.marker.set("dragPosition", h)
        });
        _.M(a.marker, "dragstart", function() {
            Cxa(a)
        });
        _.M(a.marker,
            "dragend",
            function() {
                Dxa(a, !1)
            });
        _.M(a.marker, "hover", function() {
            Dxa(a, !0)
        })
    };
    Cxa = function(a) {
        var b, c, d, e, f;
        _.Ca(function(g) {
            if (1 == g.g) return _.va(g, _.Te("streetview"), 2);
            b = g.h;
            if (a.g) return g.return();
            c = a.map.__gm;
            d = (0, _.Qa)(a.D.getUrl, a.D);
            e = c.get("panes");
            a.g = new b.Lx(e.floatPane, d, a.config);
            a.g.bindTo("description", a);
            a.g.bindTo("mode", a);
            a.g.bindTo("thumbnailPanoId", a, "panoId");
            a.g.bindTo("pixelBounds", c);
            f = new _.qG(function(h) {
                h = new _.ir(a.map, a.ka, h);
                a.ka.vb(h);
                return h
            });
            f.bindTo("latLngPosition", a.marker, "dragPosition");
            a.g.bindTo("pixelPosition", f);
            _.wa(g)
        })
    };
    Dxa = function(a, b) {
        var c = a.get("dragPosition"),
            d = a.map.getZoom(),
            e = Math.max(50, 35 * Math.pow(2, 16 - d));
        a.set("hover", b);
        a.C = !1;
        _.Te("streetview").then(function(f) {
            var g = a.Jg || void 0;
            a.h || (a.h = new f.Kx(g), a.bindTo("sloTrackingId", a.h, "sloTrackingId", !0), a.bindTo("isHover", a.h, "isHover", !0), a.h.bindTo("result", a, null, !0));
            a.h.getPanoramaByLocation(c, e, g ? void 0 : 100 > e ? "nearest" : "best", b)
        })
    };
    Bxa = function(a, b) {
        return _.Td(b - (a || 0), 0, 360)
    };
    NI = function(a, b) {
        this.fa = a;
        this.g = b;
        MI() ? Exa(a) : (b = a, a = _.bI(a), cI(b));
        this.anchor = _.ao("a", a);
        MI() ? Ywa(this.anchor, !0) : (this.anchor.style.textDecoration = "none", this.anchor.style.color = "#fff");
        this.anchor.setAttribute("target", "_new");
        a = (MI(), "B\u00e1o c\u00e1o v\u1ea5n \u0111\u1ec1");
        _.Xn(a, this.anchor);
        this.anchor.setAttribute("title", "B\u00e1o c\u00e1o v\u1ea5n \u0111\u1ec1 v\u1ec1 h\u00ecnh \u1ea3nh \u1edf Ch\u1ebf \u0111\u1ed9 xem ph\u1ed1 v\u1edbi Google");
        _.mf(this.anchor, "click", function(c) {
            var d =
                _.kA(c) ? 171380 : 171379;
            _.Q(window, _.kA(c) ? "Tdcmi" : "Tdcki");
            _.P(window, d)
        });
        Nva(this.anchor, "B\u00e1o c\u00e1o v\u1ea5n \u0111\u1ec1 v\u1ec1 h\u00ecnh \u1ea3nh \u1edf Ch\u1ebf \u0111\u1ed9 xem ph\u1ed1 v\u1edbi Google")
    };
    MI = function() {
        return "CH" === _.rd(_.sd(_.td))
    };
    Exa = function(a) {
        _.IH(a);
        a.style.fontSize = "10px";
        a.style.height = "17px";
        a.style.backgroundColor = "#f5f5f5";
        a.style.border = "1px solid #dcdcdc";
        a.style.lineHeight = "19px"
    };
    Fxa = function(a) {
        a = {
            content: (new _.IG({
                Hg: a.Hg,
                Ig: a.Ig,
                ownerElement: a.ownerElement,
                hm: !0,
                jj: a.jj
            })).element,
            ue: a.ue,
            bd: a.bd,
            ownerElement: a.ownerElement,
            title: "Ph\u00edm t\u1eaft"
        };
        a = new _.Sr(a);
        _.zm(a.element, "keyboard-shortcuts-dialog-view");
        return a
    };
    Gxa = function() {
        return "@media print {  .gm-style .gmnoprint, .gmnoprint {    display:none  }}@media screen {  .gm-style .gmnoscreen, .gmnoscreen {    display:none  }}"
    };
    OI = function(a) {
        var b = this;
        this.Ba = new _.Ii(function() {
            b.F[1] && Hxa(b);
            b.F[0] && Ixa(b);
            b.F[3] && Jxa(b);
            b.F = {};
            b.get("disableDefaultUI") && !b.h && (_.Q(b.g, "Cdn"), _.P(b.g, 148245))
        }, 0);
        this.G = a.Qu || null;
        this.X = a.Xg;
        this.Ja = a.HB || null;
        this.o = a.controlSize;
        this.qb = a.Sy || null;
        this.g = a.map || null;
        this.h = a.ED || null;
        this.Ma = this.g || this.h;
        this.zc = a.ew;
        this.Tc = a.CD || null;
        this.Sc = a.ka || null;
        this.hb = !!a.Al;
        this.Md = !!a.Ig;
        this.Ld = !!a.Hg;
        this.tc = this.Mb = this.cc = !1;
        this.D = this.Bc = this.ca = this.ga = null;
        this.J = a.Lj;
        this.Jb =
            _.Mr("Chuy\u1ec3n \u0111\u1ed5i ch\u1ebf \u0111\u1ed9 xem to\u00e0n m\u00e0n h\u00ecnh");
        this.T = null;
        this.ne = a.Gn;
        this.M = null;
        this.Ta = !1;
        this.ya = [];
        this.W = null;
        this.Nd = {};
        this.F = {};
        this.V = this.aa = this.Z = this.wa = null;
        this.Bb = _.Mr("K\u00e9o Ng\u01b0\u1eddi h\u00ecnh m\u1eafc \u00e1o v\u00e0o b\u1ea3n \u0111\u1ed3 \u0111\u1ec3 m\u1edf Ch\u1ebf \u0111\u1ed9 xem ph\u1ed1");
        this.H = null;
        this.Ga = !1;
        _.po(Gxa, this.J);
        var c = this.fb = new iI(_.L(_.sd(_.td).m, 15));
        c.bindTo("center", this);
        c.bindTo("zoom", this);
        c.bindTo("mapTypeId",
            this);
        c.bindTo("pano", this);
        c.bindTo("position", this);
        c.bindTo("pov", this);
        c.bindTo("heading", this);
        c.bindTo("tilt", this);
        a.map && _.M(c, "url_changed", function() {
            a.map.set("mapUrl", c.get("url"))
        });
        var d = new HI(_.sd(_.td));
        d.bindTo("center", this);
        d.bindTo("zoom", this);
        d.bindTo("mapTypeId", this);
        d.bindTo("pano", this);
        d.bindTo("heading", this);
        this.Od = d;
        Kxa(this);
        this.C = Lxa(this);
        this.O = null;
        Mxa(this);
        this.Y = null;
        Nxa(this);
        this.j = null;
        a.Yv && Oxa(this);
        Jxa(this);
        Pxa(this, a.Dt);
        this.ga = new fI(this.C.g, this.X);
        this.X.insertBefore(this.ga.fa, this.X.children[0]);
        this.Pd = Qxa(this);
        this.keyboardShortcuts_changed();
        _.$i[35] && Rxa(this);
        Sxa(this)
    };
    Qxa = function(a) {
        if (a.g) {
            var b = [a.C.g, a.C.h, a.C.j, a.Y, a.C.o];
            a.j && b.push(a.j)
        } else b = [a.C.g, a.C.h, a.C.j, a.C.o, a.O];
        b = new ixa({
            yi: b
        });
        a.G.addElement(b.fa, 12, !0);
        return b
    };
    Mxa = function(a) {
        if (a.h) {
            var b = document.createElement("div");
            a.O = new NI(b, a.zc);
            a.O.bindTo("pov", a.h);
            a.O.bindTo("pano", a.h);
            a.O.bindTo("takeDownUrl", a.h);
            a.h.set("rmiWidth", b.offsetWidth);
            _.$i[17] && (a.O.bindTo("visible", a.h, "reportErrorControl"), a.h.bindTo("rmiLinkData", a.O))
        }
    };
    Sxa = function(a) {
        _.Te("util").then(function(b) {
            b.Mf.g(function() {
                a.Ga = !0;
                Txa(a);
                a.H && (a.H.set("display", !1), a.H.unbindAll(), a.H = null)
            })
        })
    };
    Yxa = function(a) {
        if (Uxa(a) != a.Bc || Vxa(a) != a.cc || Wxa(a) != a.tc || PI(a) != a.Ta || Xxa(a) != a.Mb) a.F[1] = !0;
        a.F[0] = !0;
        _.Ji(a.Ba)
    };
    QI = function(a) {
        return a.get("disableDefaultUI")
    };
    PI = function(a) {
        var b = a.get("streetViewControl"),
            c = a.get("disableDefaultUI"),
            d = !!a.get("size");
        if (void 0 !== b || c) _.Q(a.g, b ? "Cvy" : "Cvn"), _.P(a.g, b ? 148260 : 148261);
        null == b && (b = !c);
        a = d && !a.h;
        return b && a
    };
    Zxa = function(a) {
        return !a.get("disableDefaultUI") && !!a.h
    };
    Pxa = function(a, b) {
        var c = a.G;
        _.mb(b, function(d, e) {
            if (d) {
                var f = function(g) {
                    if (g) {
                        var h = g.index;
                        _.Wd(h) || (h = 1E3);
                        h = Math.max(h, -999);
                        _.bo(g, Math.min(999999, _.Yd(g.style.zIndex || 0)));
                        c.addElement(g, e, !1, h)
                    }
                };
                d.forEach(f);
                _.M(d, "insert_at", function(g) {
                    f(d.getAt(g))
                });
                _.M(d, "remove_at", function(g, h) {
                    c.Fd(h)
                })
            }
        })
    };
    Rxa = function(a) {
        if (a.g) {
            var b = new PH(document.createElement("div"));
            b.bindTo("card", a.g.__gm);
            b = b.getDiv();
            a.G.addElement(b, 1, !0, .1)
        }
    };
    Jxa = function(a) {
        a.T && (a.T.unbindAll(), wwa(a.T), a.T = null, a.G.Fd(a.Jb));
        var b = _.Mr("Chuy\u1ec3n \u0111\u1ed5i ch\u1ebf \u0111\u1ed9 xem to\u00e0n m\u00e0n h\u00ecnh"),
            c = new xwa(a.J, b, a.ne, a.o);
        c.bindTo("display", a, "fullscreenControl");
        c.bindTo("disableDefaultUI", a);
        c.bindTo("mapTypeId", a);
        var d = a.get("fullscreenControlOptions") || {};
        a.G.addElement(b, d && d.position || 7, !0, -1007);
        a.T = c;
        a.Jb = b
    };
    Lxa = function(a) {
        var b = new mxa(a.X, a.J, a.Ma, a.hb);
        b.bindTo("size", a);
        b.bindTo("rmiWidth", a);
        b.bindTo("attributionText", a);
        b.bindTo("fontLoaded", a);
        b.bindTo("mapTypeId", a);
        b.bindTo("isCustomPanorama", a);
        b.bindTo("logoWidth", a);
        b.g.addListener("click", function(c) {
            a.ca || (a.ca = $xa(a));
            a.Ma.__gm.get("developerProvidedDiv").appendChild(a.ca.element);
            a.ca.show();
            var d = _.kA(c) ? 164970 : 164969;
            _.Q(window, _.kA(c) ? "Kscmi" : "Kscki");
            _.P(window, d)
        });
        return b
    };
    $xa = function(a) {
        var b = a.Ma.__gm,
            c = b.get("innerContainer"),
            d = b.get("developerProvidedDiv"),
            e = Fxa({
                Hg: a.Ld,
                Ig: a.Md,
                ue: function() {
                    _.ho(c).catch(function() {})
                },
                bd: a.X,
                ownerElement: d,
                jj: a.g ? "map" : "street_view"
            });
        e.addListener("hide", function() {
            d.removeChild(e.element)
        });
        return e
    };
    Kxa = function(a) {
        if (!_.$i[2]) {
            var b = !!_.$i[21];
            a.g ? b = Gwa(a.g, a.fb, b) : (b = new jI(a.h, a.fb, b), Fwa(b, !0));
            b = b.getDiv();
            a.G.addElement(b, 10, !0, -1E3);
            a.set("logoWidth", b.offsetWidth)
        }
    };
    Oxa = function(a) {
        if (a.g) {
            var b = _.sd(_.td);
            a.j = new uI(document.createElement("div"), a.g, _.L(b.m, 15));
            a.j.bindTo("available", a, "rmiAvailable");
            a.j.bindTo("bounds", a);
            _.$i[17] ? (a.j.bindTo("enabled", a, "reportErrorControl"), a.g.bindTo("rmiLinkData", a.j)) : a.j.set("enabled", !0);
            a.j.bindTo("mapTypeId", a);
            a.j.bindTo("sessionState", a.Od);
            a.bindTo("rmiWidth", a.j, "width");
            _.M(a.j, "rmilinkdata_changed", function() {
                var c = a.j.get("rmiLinkData");
                a.g.set("rmiUrl", c && c.url)
            })
        }
    };
    Txa = function(a) {
        a.la && (a.la.unbindAll && a.la.unbindAll(), a.la = null);
        a.wa && (a.wa.unbindAll(), a.wa = null);
        a.Z && (a.Z.unbindAll(), a.Z = null);
        a.W && (aya(a, a.W), _.Nj(a.W.ra), a.W = null)
    };
    Ixa = function(a) {
        Txa(a);
        if (a.Ja && !a.Ga) {
            var b = bya(a);
            if (b) {
                var c = _.ao("div");
                _.IH(c);
                c.style.margin = _.jn(a.o >> 2);
                _.mf(c, "mouseover", function() {
                    _.bo(c, 1E6)
                });
                _.mf(c, "mouseout", function() {
                    _.bo(c, 0)
                });
                _.bo(c, 0);
                var d = a.get("mapTypeControlOptions") || {},
                    e = a.Z = new cwa(a.Ja, d.mapTypeIds);
                e.bindTo("aerialAvailableAtZoom", a);
                e.bindTo("zoom", a);
                var f = e.buttons;
                a.G.addElement(c, d.position || 1, !1, .2);
                d = null;
                2 == b ? (d = new rI(c, f, a.o), e.bindTo("mapTypeId", d)) : d = new Swa(c, f, _.nI, a.o);
                b = a.wa = new sI(e.mapping);
                b.set("labels", !0);
                d.bindTo("mapTypeId", b, "internalMapTypeId");
                d.bindTo("labels", b);
                d.bindTo("terrain", b);
                d.bindTo("tilt", a, "desiredTilt");
                d.bindTo("fontLoaded", a);
                d.bindTo("mapSize", a, "size");
                d.bindTo("display", a, "mapTypeControl");
                b.bindTo("mapTypeId", a);
                _.N(c, "resize");
                a.W = {
                    ra: c,
                    Nn: null
                };
                a.la = d
            }
        }
    };
    bya = function(a) {
        if (!a.Ja) return null;
        var b = (a.get("mapTypeControlOptions") || {}).style || 0,
            c = a.get("mapTypeControl"),
            d = QI(a);
        if (void 0 === c && d || void 0 !== c && !c) return _.Q(a.g, "Cmn"), _.P(a.g, 148251), null;
        1 == b ? (_.Q(a.g, "Cmh"), _.P(a.g, 148253)) : 2 == b && (_.Q(a.g, "Cmd"), _.P(a.g, 148252));
        return 2 == b || 1 == b ? b : 1
    };
    cya = function(a, b) {
        b = a.M = new BI(b, a.o, _.tw.Tb(), a.J);
        b.bindTo("zoomRange", a);
        b.bindTo("display", a, "zoomControl");
        b.bindTo("disableDefaultUI", a);
        b.bindTo("mapSize", a, "size");
        b.bindTo("mapTypeId", a);
        b.bindTo("zoom", a);
        return b.getDiv()
    };
    dya = function(a) {
        var b = new _.LC(RH, {
                Vi: _.tw.Tb()
            }),
            c = new ZH(b, a.o, a.J);
        c.bindTo("pov", a);
        c.bindTo("disableDefaultUI", a);
        c.bindTo("panControl", a);
        c.bindTo("mapSize", a, "size");
        return b.ra
    };
    eya = function(a) {
        var b = _.ao("div");
        _.IH(b);
        a.D = new dxa(b, a.o, a.J);
        a.D.bindTo("mapSize", a, "size");
        a.D.bindTo("rotateControl", a);
        a.D.bindTo("heading", a);
        a.D.bindTo("tilt", a);
        a.D.bindTo("aerialAvailableAtZoom", a);
        return b
    };
    fya = function(a) {
        var b = _.ao("div"),
            c = a.aa = new II(b, a.o);
        c.bindTo("pano", a);
        c.bindTo("floors", a);
        c.bindTo("floorId", a);
        return b
    };
    RI = function(a) {
        a.F[1] = !0;
        _.Ji(a.Ba)
    };
    Hxa = function(a) {
        function b(m, p) {
            if (!l[m]) {
                var q = a.o >> 2,
                    r = 12 + (a.o >> 1),
                    t = document.createElement("div");
                _.IH(t);
                _.Jn(t, "gm-bundled-control");
                10 === m || 11 === m || 12 === m || 6 === m || 9 === m ? _.Jn(t, "gm-bundled-control-on-bottom") : _.HH(t, "gm-bundled-control-on-bottom");
                t.style.margin = _.jn(q);
                _.co(t);
                l[m] = new gI(t, m, r);
                a.G.addElement(t, m, !1, .1)
            }
            m = l[m];
            m.add(p);
            a.ya.push({
                ra: p,
                Nn: m
            })
        }

        function c(m) {
            return (a.get(m) || {}).position
        }
        a.M && (lxa(a.M), a.M.unbindAll(), a.M = null);
        a.D && (a.D.unbindAll(), a.D = null);
        a.aa && (a.aa.unbindAll(),
            a.aa = null);
        for (var d = _.A(a.ya), e = d.next(); !e.done; e = d.next()) aya(a, e.value);
        a.ya = [];
        d = a.cc = Vxa(a);
        var f = a.Bc = Uxa(a),
            g = a.Ta = PI(a),
            h = a.tc = Wxa(a);
        a.Mb = Xxa(a);
        e = d && (c("panControlOptions") || 9);
        d = f && (c("zoomControlOptions") || 3 == f && 6 || 9);
        var k = 3 == f || _.go();
        g = g && (c("streetViewControlOptions") || 9);
        h = h && (c("rotateControlOptions") || k && 6 || 9);
        var l = a.Nd;
        d && (f = cya(a, f), b(d, f));
        g && (gya(a), b(g, a.Bb));
        e && a.h && _.Hn().transform && (f = dya(a), b(e, f));
        h && (e = eya(a), b(h, e));
        a.V && (a.V.remove(), a.V = null);
        if (e = Zxa(a) && 9) f = fya(a),
            b(e, f);
        a.D && a.M && a.M.rm && h == d && a.D.bindTo("mouseover", a.M.rm);
        d = _.A(a.ya);
        for (e = d.next(); !e.done; e = d.next()) _.N(e.value.ra, "resize")
    };
    Vxa = function(a) {
        var b = a.get("panControl"),
            c = QI(a);
        if (void 0 !== b || c) return a.h || (_.Q(a.g, b ? "Cpy" : "Cpn"), _.P(a.g, b ? 148255 : 148254)), !!b;
        b = a.get("size");
        return _.go() || !b ? !1 : 400 <= b.width && 370 <= b.height || !!a.h
    };
    Xxa = function(a) {
        return a.h ? !1 : QI(a) ? 1 == a.get("myLocationControl") : 0 != a.get("myLocationControl")
    };
    Wxa = function(a) {
        var b = a.get("rotateControl"),
            c = QI(a);
        if (void 0 !== b || c) _.Q(a.g, b ? "Cry" : "Crn"), _.P(a.g, b ? 148257 : 148256);
        return !a.get("size") || a.h ? !1 : c ? 1 == b : 0 != b
    };
    Uxa = function(a) {
        var b = a.get("zoomControl"),
            c = QI(a);
        return 0 == b || c && void 0 === b ? (a.h || (_.Q(a.g, "Czn"), _.P(a.g, 148262)), null) : a.get("size") ? 1 : null
    };
    SI = function(a) {
        if (a.Y) {
            var b = a.get("scaleControl");
            void 0 !== b && (_.Q(a.g, b ? "Csy" : "Csn"), _.P(a.g, b ? 148259 : 148258));
            b ? (a = a.Y, a.h = !0, xI(a)) : (a = a.Y, a.h = !1, xI(a))
        }
    };
    Nxa = function(a) {
        if (a.g) {
            var b = _.Mr("Map Scale");
            _.co(b);
            _.eo(b);
            a.Y = new fxa(b, _.bI(b, a.J), new _.jr([_.ns(a, "projection"), _.ns(a, "bottomRight"), _.ns(a, "zoom")], _.Jsa));
            SI(a)
        }
    };
    gya = function(a) {
        if (!a.H && !a.Ga && a.qb && a.g) {
            var b = a.H = new LI(a.g, a.qb, a.Bb, a.J, a.zc, _.td, a.Sc, a.o, a.hb, a.Tc || void 0);
            b.bindTo("mapHeading", a, "heading");
            b.bindTo("tilt", a);
            b.bindTo("projection", a.g);
            b.bindTo("mapTypeId", a);
            a.bindTo("panoramaVisible", b);
            b.bindTo("mapSize", a, "size");
            b.bindTo("display", a, "streetViewControl");
            b.bindTo("disableDefaultUI", a);
            hya(a)
        }
    };
    hya = function(a) {
        var b = a.H;
        if (b) {
            var c = b.F,
                d = a.get("streetView");
            if (d != c) {
                if (c) {
                    var e = c.__gm;
                    e.unbind("result");
                    e.unbind("heading");
                    c.unbind("passiveLogo");
                    c.g.removeListener(a.fw, a);
                    c.g.set(!1)
                }
                d && (c = d.__gm, null != c.get("result") && b.set("result", c.get("result")), c.bindTo("isHover", b), c.bindTo("result", b), null != c.get("heading") && b.set("heading", c.get("heading")), c.bindTo("heading", b), d.bindTo("passiveLogo", a), d.g.addListener(a.fw, a), a.set("panoramaVisible", d.get("visible")), b.bindTo("client", d));
                b.F =
                    d
            }
        }
    };
    aya = function(a, b) {
        b.Nn ? (b.Nn.remove(b.ra), delete b.Nn) : a.G.Fd(b.ra)
    };
    _.jya = function(a, b) {
        var c = document.createElement("div"),
            d = c.style;
        d.backgroundColor = "white";
        d.fontWeight = "500";
        d.fontFamily = "Roboto, sans-serif";
        d.padding = "15px 25px";
        d.boxSizing = "border-box";
        d.top = "5px";
        d = document.createElement("div");
        var e = document.createElement("img");
        e.alt = "";
        e.src = _.kw + "api-3/images/google_gray.svg";
        e.style.border = e.style.margin = e.style.padding = 0;
        e.style.height = "17px";
        e.style.verticalAlign = "middle";
        e.style.width = "52px";
        _.co(e);
        d.appendChild(e);
        c.appendChild(d);
        d = document.createElement("div");
        d.style.lineHeight = "20px";
        d.style.margin = "15px 0";
        e = document.createElement("span");
        e.style.color = "rgba(0,0,0,0.87)";
        e.style.fontSize = "14px";
        e.innerText = "Trang n\u00e0y kh\u00f4ng th\u1ec3 t\u1ea3i Google Maps \u0111\u00fang c\u00e1ch.";
        d.appendChild(e);
        c.appendChild(d);
        d = document.createElement("table");
        d.style.width = "100%";
        e = document.createElement("tr");
        var f = document.createElement("td");
        f.style.lineHeight = "16px";
        f.style.verticalAlign = "middle";
        var g = document.createElement("a");
        Pva(g, b);
        g.innerText =
            "B\u1ea1n c\u00f3 s\u1edf h\u1eefu trang web n\u00e0y kh\u00f4ng?";
        g.target = "_blank";
        g.setAttribute("rel", "noopener");
        g.style.color = "rgba(0, 0, 0, 0.54)";
        g.style.fontSize = "12px";
        g.onclick = function() {
            _.Q(a, "Dl");
            _.P(a, 148243)
        };
        f.appendChild(g);
        e.appendChild(f);
        _.Mm(iya);
        b = document.createElement("td");
        b.style.textAlign = "right";
        f = document.createElement("button");
        f.className = "dismissButton";
        f.innerText = "OK";
        f.onclick = function() {
            a.removeChild(c);
            _.N(a, "dmd");
            _.Q(a, "Dd");
            _.P(a, 148242)
        };
        b.appendChild(f);
        e.appendChild(b);
        d.appendChild(e);
        c.appendChild(d);
        a.appendChild(c);
        _.Q(a, "D0");
        _.P(a, 148244);
        return c
    };
    TI = function(a) {
        var b = this;
        this.h = a;
        this.Ba = new _.Ii(function() {
            return b.j()
        }, 0);
        _.nn(a, "resize", this, this.j);
        this.g = new _.w.Map;
        this.o = new _.w.Map;
        a = _.A([1, 2, 3, 5, 7, 4, 13, 8, 6, 9, 10, 11, 12]);
        for (var c = a.next(); !c.done; c = a.next()) {
            c = c.value;
            var d = document.createElement("div");
            this.h.appendChild(d);
            this.o.set(c, d);
            this.g.set(c, [])
        }
    };
    UI = function(a, b) {
        if (!GH(a)) return 0;
        b = !b && _.Yd(a.dataset.controlWidth);
        if (!_.Wd(b) || isNaN(b)) b = a.offsetWidth;
        a = _.DG(a);
        b += _.Yd(a.marginLeft) || 0;
        return b += _.Yd(a.marginRight) || 0
    };
    VI = function(a, b) {
        if (!GH(a)) return 0;
        b = !b && _.Yd(a.dataset.controlHeight);
        if (!_.Wd(b) || isNaN(b)) b = a.offsetHeight;
        a = _.DG(a);
        b += _.Yd(a.marginTop) || 0;
        return b += _.Yd(a.marginBottom) || 0
    };
    kya = function(a) {
        for (var b = 0, c = _.A(a), d = c.next(); !d.done; d = c.next()) b = Math.max(d.value.height, b);
        d = c = 0;
        for (var e = a.length; 0 < e; --e) {
            var f = a[e - 1];
            if (b === f.height) {
                f.width > d && f.width > f.height ? d = f.height : c = f.width;
                break
            } else d = Math.max(f.height, d)
        }
        return new _.Fg(c, d)
    };
    WI = function(a, b, c, d) {
        var e = 0,
            f = 0,
            g = [];
        a = _.A(a);
        for (var h = a.next(); !h.done; h = a.next()) {
            var k = h.value;
            h = k.border;
            k = k.element;
            var l = UI(k);
            var m = UI(k, !0),
                p = VI(k),
                q = VI(k, !0);
            k.style[b] = _.jn("left" === b ? e : e + (l - m));
            k.style[c] = _.jn("top" === c ? 0 : p - q);
            l = e + l;
            p > f && (f = p, d.push({
                minWidth: e,
                height: f
            }));
            e = l;
            h || g.push(new _.Fg(e, p));
            k.style.visibility = ""
        }
        return kya(g)
    };
    XI = function(a, b, c, d) {
        var e = 0,
            f = [];
        a = _.A(a);
        for (var g = a.next(); !g.done; g = a.next()) {
            var h = g.value;
            g = h.border;
            h = h.element;
            for (var k = UI(h), l = VI(h), m = UI(h, !0), p = VI(h, !0), q = 0, r = _.A(d), t = r.next(); !t.done; t = r.next()) {
                t = t.value;
                if (t.minWidth > k) break;
                q = t.height
            }
            e = Math.max(q, e);
            h.style[c] = _.jn("top" === c ? e : e + l - p);
            h.style[b] = _.jn("left" === b ? 0 : k - m);
            e += l;
            g || f.push(new _.Fg(k, e));
            h.style.visibility = ""
        }
        return kya(f)
    };
    YI = function(a, b, c, d) {
        for (var e = 0, f = 0, g = _.A(a), h = g.next(); !h.done; h = g.next()) {
            var k = h.value;
            h = k.border;
            k = k.element;
            var l = UI(k),
                m = VI(k),
                p = UI(k, !0);
            "left" === b ? k.style.left = "0" : "right" === b ? k.style.right = _.jn(l - p) : k.style.left = _.jn((c - p) / 2);
            e += m;
            h || (f = Math.max(l, f))
        }
        b = (d - e) / 2;
        a = _.A(a);
        for (c = a.next(); !c.done; c = a.next()) c = c.value.element, c.style.top = _.jn(b), b += VI(c), c.style.visibility = "";
        return f
    };
    lya = function(a, b, c) {
        for (var d = 0, e = 0, f = _.A(a), g = f.next(); !g.done; g = f.next()) {
            var h = g.value;
            g = h.border;
            h = h.element;
            var k = UI(h),
                l = VI(h),
                m = VI(h, !0);
            h.style[b] = _.jn("top" === b ? 0 : l - m);
            d += k;
            g || (e = Math.max(l, e))
        }
        b = (c - d) / 2;
        a = _.A(a);
        for (c = a.next(); !c.done; c = a.next()) c = c.value.element, c.style.left = _.jn(b), b += UI(c), c.style.visibility = "";
        return e
    };
    mya = function(a, b, c, d, e, f, g, h, k, l, m, p, q, r, t, v, x) {
        var z = b.get("streetView");
        k = b.__gm;
        if (z && k) {
            p = new _.JG(_.By(), z.get("client"));
            z = _.Fda[z.get("client")];
            var y = new OI({
                    Sy: function(T) {
                        return q.fromContainerPixelToLatLng(new _.R(T.clientX, T.clientY))
                    },
                    Dt: b.controls,
                    Lj: l,
                    Gn: m,
                    Qu: a,
                    map: b,
                    HB: b.mapTypes,
                    Xg: d,
                    Yv: !0,
                    ka: r,
                    controlSize: b.get("controlSize") || 40,
                    CD: z,
                    ew: p,
                    Al: t,
                    Ig: v,
                    Hg: x
                }),
                G = new _.rG(["bounds"], "bottomRight", function(T) {
                    return T && _.xm(T)
                }),
                I, aa;
            _.on(b, "idle", function() {
                var T = b.get("bounds");
                T != I &&
                    (y.set("bounds", T), G.set("bounds", T), I = T);
                T = b.get("center");
                T != aa && (y.set("center", T), aa = T)
            });
            y.bindTo("bottomRight", G);
            y.bindTo("disableDefaultUI", b);
            y.bindTo("heading", b);
            y.bindTo("projection", b);
            y.bindTo("reportErrorControl", b);
            y.bindTo("passiveLogo", b);
            y.bindTo("zoom", k);
            y.bindTo("mapTypeId", c);
            y.bindTo("attributionText", e);
            y.bindTo("zoomRange", g);
            y.bindTo("aerialAvailableAtZoom", h);
            y.bindTo("tilt", h);
            y.bindTo("desiredTilt", h);
            y.bindTo("keyboardShortcuts", b, "keyboardShortcuts", !0);
            y.bindTo("mapTypeControlOptions",
                b, null, !0);
            y.bindTo("panControlOptions", b, null, !0);
            y.bindTo("rotateControlOptions", b, null, !0);
            y.bindTo("scaleControlOptions", b, null, !0);
            y.bindTo("streetViewControlOptions", b, null, !0);
            y.bindTo("zoomControlOptions", b, null, !0);
            y.bindTo("mapTypeControl", b);
            y.bindTo("myLocationControlOptions", b);
            y.bindTo("fullscreenControlOptions", b, null, !0);
            b.get("fullscreenControlOptions") && y.notify("fullscreenControlOptions");
            y.bindTo("panControl", b);
            y.bindTo("rotateControl", b);
            y.bindTo("motionTrackingControl", b);
            y.bindTo("motionTrackingControlOptions",
                b, null, !0);
            y.bindTo("scaleControl", b);
            y.bindTo("streetViewControl", b);
            y.bindTo("fullscreenControl", b);
            y.bindTo("zoomControl", b);
            y.bindTo("myLocationControl", b);
            y.bindTo("rmiAvailable", f, "available");
            y.bindTo("streetView", b);
            y.bindTo("fontLoaded", k);
            y.bindTo("size", k);
            k.bindTo("renderHeading", y);
            _.qf(y, "panbyfraction", k)
        }
    };
    nya = function(a, b, c, d, e, f, g, h) {
        var k = new _.JG(_.By(), g.get("client")),
            l = new OI({
                Dt: f,
                Lj: d,
                Gn: h,
                Qu: e,
                Xg: c,
                controlSize: g.get("controlSize") || 40,
                Yv: !1,
                ED: g,
                ew: k
            });
        l.set("streetViewControl", !1);
        l.bindTo("attributionText", b, "copyright");
        l.set("mapTypeId", "streetview");
        l.set("tilt", !0);
        l.bindTo("heading", b);
        l.bindTo("zoom", b, "zoomFinal");
        l.bindTo("zoomRange", b);
        l.bindTo("pov", b, "pov");
        l.bindTo("position", g);
        l.bindTo("pano", g);
        l.bindTo("passiveLogo", g);
        l.bindTo("floors", b);
        l.bindTo("floorId", b);
        l.bindTo("rmiWidth",
            g);
        l.bindTo("fullscreenControlOptions", g, null, !0);
        l.bindTo("panControlOptions", g, null, !0);
        l.bindTo("zoomControlOptions", g, null, !0);
        l.bindTo("fullscreenControl", g);
        l.bindTo("panControl", g);
        l.bindTo("zoomControl", g);
        l.bindTo("disableDefaultUI", g);
        l.bindTo("fontLoaded", g.__gm);
        l.bindTo("size", b);
        a.view && a.view.addListener("scene_changed", function() {
            var m = a.view.get("scene");
            l.set("isCustomPanorama", "c" === m)
        });
        l.Ba.xc();
        _.qf(l, "panbyfraction", a)
    };
    ZI = function(a, b, c) {
        this.O = a;
        this.M = b;
        this.J = c;
        this.j = this.h = 0;
        this.o = null;
        this.G = this.g = 0;
        this.D = this.H = null;
        _.nn(a, "keydown", this, this.KA);
        _.nn(a, "keypress", this, this.Py);
        _.nn(a, "keyup", this, this.TC);
        this.C = {};
        this.F = {}
    };
    $I = function(a, b) {
        _.P(window, a);
        _.Q(window, b)
    };
    oya = function(a) {
        var b = a.get("zoom");
        _.Wd(b) && (a.set("zoom", b + 1), $I(165374, "Zmki"))
    };
    pya = function(a) {
        var b = a.get("zoom");
        _.Wd(b) && (a.set("zoom", b - 1), $I(165374, "Zmki"))
    };
    aJ = function(a, b, c) {
        _.N(a, "panbyfraction", b, c);
        $I(165373, "Pmki")
    };
    qya = function(a, b) {
        return !!(b.target !== a.O || b.ctrlKey || b.altKey || b.metaKey || 0 == a.get("enabled"))
    };
    sya = function(a, b, c, d, e) {
        var f = new ZI(b, d, e);
        f.bindTo("zoom", a);
        f.bindTo("enabled", a, "keyboardShortcuts");
        d && f.bindTo("tilt", a.__gm);
        e && f.bindTo("heading", a);
        (d || e) && _.qf(f, "tiltrotatebynow", a.__gm);
        _.qf(f, "panbyfraction", a.__gm);
        _.qf(f, "panbynow", a.__gm);
        _.qf(f, "panby", a.__gm);
        rya(a, b, d, e);
        var g = a.__gm.G,
            h;
        _.on(a, "streetview_changed", function() {
            var k = a.get("streetView"),
                l = h;
            l && _.gf(l);
            h = null;
            k && (h = _.on(k, "visible_changed", function() {
                k.getVisible() && k === g ? (b.blur(), c.style.visibility = "hidden") : c.style.visibility =
                    ""
            }))
        })
    };
    rya = function(a, b, c, d) {
        c = new _.IG({
            Hg: d,
            Ig: c,
            ownerElement: b,
            hm: !1,
            jj: "map"
        });
        var e = _.Bk();
        c.element.id = e;
        c.element.style.display = "none";
        b.appendChild(c.element);
        _.on(a, "keyboardshortcuts_changed", function() {
            _.Im(a) ? b.setAttribute("aria-describedby", e) : b.removeAttribute("aria-describedby")
        })
    };
    bJ = function() {
        this.qs = TI;
        this.DB = mya;
        this.GB = nya;
        this.EB = sya
    };
    Yva = {};
    _.Ua(OH, _.O);
    _.B(cwa, _.O);
    _.B(PH, _.O);
    PH.prototype.card_changed = function() {
        var a = this.get("card");
        this.g && this.h.removeChild(this.g);
        if (a) {
            var b = this.g = _.ao("div");
            b.style.backgroundColor = "white";
            b.appendChild(a);
            b.style.margin = _.jn(10);
            b.style.padding = _.jn(1);
            _.jA(b, "0 1px 4px -1px rgba(0,0,0,0.3)");
            JH(b, _.jn(2));
            this.h.appendChild(b);
            this.g = b
        } else this.g = null
    };
    PH.prototype.getDiv = function() {
        return this.h
    };
    var YH = _.Vl(_.ab(".gm-control-active>img{-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:none;left:50%;pointer-events:none;position:absolute;top:50%;-webkit-transform:translate(-50%,-50%);-moz-transform:translate(-50%,-50%);-ms-transform:translate(-50%,-50%);-o-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}.gm-control-active>img:nth-child(1){display:block}.gm-control-active:focus>img:nth-child(1),.gm-control-active:hover>img:nth-child(1),.gm-control-active:active>img:nth-child(1),.gm-control-active:disabled>img:nth-child(1){display:none}.gm-control-active:focus>img:nth-child(2),.gm-control-active:hover>img:nth-child(2){display:block}.gm-control-active:active>img:nth-child(3){display:block}.gm-control-active:disabled>img:nth-child(4){display:block}sentinel{}\n"));
    _.Ua(RH, _.JC);
    RH.prototype.fill = function(a) {
        _.HC(this, 0, _.$A(a))
    };
    var QH = "t-avKK8hDgg9Q";
    _.B(SH, _.F);
    SH.prototype.getHeading = function() {
        return _.xd(this.m, 1)
    };
    SH.prototype.setHeading = function(a) {
        _.D(this.m, 1, a)
    };
    var TH = {},
        UH = null;
    _.Ua(WH, _.Ci);
    WH.prototype.h = function(a) {
        this.j(a)
    };
    _.Ua(XH, WH);
    XH.prototype.stop = function(a) {
        VH(this);
        this.g = 0;
        a && (this.progress = 1);
        owa(this, this.progress);
        this.h("stop");
        this.h("end")
    };
    XH.prototype.Db = function() {
        0 == this.g || this.stop(!1);
        this.h("destroy");
        XH.Ke.Db.call(this)
    };
    XH.prototype.h = function(a) {
        this.j(new pwa(a, this))
    };
    _.Ua(pwa, _.$h);
    _.B(ZH, _.O);
    ZH.prototype.changed = function() {
        !this.j && this.g && (this.g.stop(), this.g = null);
        var a = this.get("pov");
        if (a) {
            var b = new SH;
            b.setHeading(_.Td(-a.heading, 0, 360));
            _.dm(_.K(b.m, 3, _.LA), _.MA(_.sb(_.Nr["compass_background.svg"])));
            _.dm(_.K(b.m, 4, _.LA), _.MA(_.sb(_.Nr["compass_needle_normal.svg"])));
            _.dm(_.K(b.m, 5, _.LA), _.MA(_.sb(_.Nr["compass_needle_hover.svg"])));
            _.dm(_.K(b.m, 6, _.LA), _.MA(_.sb(_.Nr["compass_needle_active.svg"])));
            _.dm(_.K(b.m, 7, _.LA), _.MA(_.sb(_.Nr["compass_rotate_normal.svg"])));
            _.dm(_.K(b.m,
                8, _.LA), _.MA(_.sb(_.Nr["compass_rotate_hover.svg"])));
            _.dm(_.K(b.m, 9, _.LA), _.MA(_.sb(_.Nr["compass_rotate_active.svg"])));
            _.D(b.m, 10, "Xoay ng\u01b0\u1ee3c chi\u1ec1u kim \u0111\u1ed3ng h\u1ed3");
            _.D(b.m, 11, "Xoay theo chi\u1ec1u kim \u0111\u1ed3ng h\u1ed3");
            _.D(b.m, 12, "\u0110\u1eb7t l\u1ea1i ch\u1ebf \u0111\u1ed9 xem");
            this.h.update([b])
        }
    };
    ZH.prototype.mapSize_changed = function() {
        $H(this)
    };
    ZH.prototype.disableDefaultUI_changed = function() {
        $H(this)
    };
    ZH.prototype.panControl_changed = function() {
        $H(this)
    };
    _.B(xwa, _.O);
    var vwa = [{
        Lz: -52,
        close: -78,
        top: -86,
        backgroundColor: "#fff"
    }, {
        Lz: 0,
        close: -26,
        top: -86,
        backgroundColor: "#222"
    }];
    var ywa = _.Vl(_.ab(".gm-style .gm-style-cc a,.gm-style .gm-style-cc button,.gm-style .gm-style-cc span,.gm-style .gm-style-mtc div{font-size:10px;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}.gm-style .gm-style-cc a,.gm-style .gm-style-cc button,.gm-style .gm-style-cc span{outline-offset:3px}sentinel{}\n"));
    _.B(eI, _.O);
    _.n = eI.prototype;
    _.n.fontLoaded_changed = function() {
        var a = this;
        return _.Ca(function(b) {
            dI(a);
            _.wa(b)
        })
    };
    _.n.keyboardShortcutsShown_changed = function() {
        dI(this)
    };
    _.n.Xh = function() {
        this.get("keyboardShortcutsShown") && (this.fa.style.display = "", this.g.textContent = "", this.g.appendChild(this.C), _.BA(), _.N(this, "update"))
    };
    _.n.Wh = function() {
        this.get("keyboardShortcutsShown") && (this.fa.style.display = "", this.g.textContent = "", this.g.textContent = "Ph\u00edm t\u1eaft", _.BA(), _.N(this, "update"))
    };
    _.n.Yb = function() {
        this.get("keyboardShortcutsShown") || (this.fa.style.display = "none", _.N(this, "update"))
    };
    _.n.Yd = function() {
        return this.fa
    };
    _.B(fI, _.O);
    fI.prototype.Qp = function() {
        this.g = !0;
        Bwa(this)
    };
    gI.prototype.add = function(a) {
        a.style.position = "absolute";
        this.g ? this.fa.insertBefore(a, this.fa.firstChild) : this.fa.appendChild(a);
        a = Cwa(this, a);
        this.elements.push(a);
        hI(this, a)
    };
    gI.prototype.remove = function(a) {
        var b = this;
        this.fa.removeChild(a);
        Qva(this.elements, function(c, d) {
            c.element === a && (b.elements.splice(d, 1), b.onRemove(c))
        })
    };
    gI.prototype.onRemove = function(a) {
        a && (hI(this, a), a.dr && (_.gf(a.dr), delete a.dr))
    };
    _.Nk("api-3/images/my_location_spinner", !0, !0);
    _.Ua(iI, _.O);
    iI.prototype.changed = function(a) {
        if ("url" != a)
            if (this.get("pano")) {
                a = this.get("pov");
                var b = this.get("position");
                a && b && (a = _.vua(a, b, this.get("pano"), this.g), this.set("url", a))
            } else {
                a = {};
                if (b = this.get("center")) b = new _.we(b.lat(), b.lng()), a.ll = b.toUrlValue();
                b = this.get("zoom");
                _.Wd(b) && (a.z = b);
                b = this.get("mapTypeId");
                (b = "terrain" == b ? "p" : "hybrid" == b ? "h" : _.hw[b]) && (a.t = b);
                if (b = this.get("pano")) {
                    a.z = 17;
                    a.layer = "c";
                    var c = this.get("position");
                    c && (a.cbll = c.toUrlValue());
                    a.panoid = b;
                    (b = this.get("pov")) && (a.cbp =
                        "12," + b.heading + ",," + Math.max(b.zoom - 3) + "," + -b.pitch)
                }
                a.hl = _.qd(_.sd(_.td));
                a.gl = _.rd(_.sd(_.td));
                a.mapclient = _.$i[35] ? "embed" : "apiv3";
                var d = [];
                _.Qd(a, function(e, f) {
                    d.push(e + "=" + f)
                });
                this.set("url", this.g + "?" + d.join("&"))
            }
    };
    jI.prototype.getDiv = function() {
        return this.j
    };
    _.B(Hwa, _.O);
    _.B(mI, _.O);
    mI.prototype.ob = function() {
        return this.g
    };
    var Jwa = _.Vl(_.ab(".ssQIHO-checkbox-menu-item>span>span{background-color:#000;display:inline-block}@media (forced-colors:active),(prefers-contrast:more){.ssQIHO-checkbox-menu-item>span>span{background-color:ButtonText}}\n"));
    _.B(oI, _.O);
    oI.prototype.ob = function() {
        return this.g
    };
    _.B(pI, _.O);
    pI.prototype.ob = function() {
        return this.g
    };
    _.Ua(Lwa, _.O);
    _.B(qI, _.O);
    qI.prototype.D = function() {
        var a = this.g;
        a.timeout && (window.clearTimeout(a.timeout), a.timeout = null)
    };
    qI.prototype.active_changed = function() {
        this.D();
        if (this.get("active")) Pwa(this);
        else {
            var a = this.g;
            a.g && (_.mb(a.g, _.gf), a.g = null);
            a.contains(document.activeElement) && this.o.focus();
            this.h = null;
            _.fA(a)
        }
    };
    var Twa = _.Vl(_.ab(".gm-style .gm-style-mtc label,.gm-style .gm-style-mtc div{font-weight:400}.gm-style .gm-style-mtc ul,.gm-style .gm-style-mtc li{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}sentinel{}\n"));
    _.B(Swa, _.O);
    _.B(rI, _.O);
    rI.prototype.mapSize_changed = function() {
        Vwa(this)
    };
    rI.prototype.display_changed = function() {
        Vwa(this)
    };
    _.B(sI, _.O);
    sI.prototype.changed = function(a) {
        if (!this.g)
            if ("mapTypeId" === a) {
                a = this.get("mapTypeId");
                var b = this.map[a];
                b && b.mapTypeId && (a = b.mapTypeId);
                tI(this, "internalMapTypeId", a);
                b && b.Ml && tI(this, b.Ml, b.value)
            } else {
                a = this.get("internalMapTypeId");
                if (this.map) {
                    b = _.A(_.u(Object, "entries").call(Object, this.map));
                    for (var c = b.next(); !c.done; c = b.next()) {
                        var d = _.A(c.value);
                        c = d.next().value;
                        (d = d.next().value) && d.mapTypeId === a && d.Ml && this.get(d.Ml) == d.value && (a = c)
                    }
                }
                tI(this, "mapTypeId", a)
            }
    };
    _.B(uI, _.O);
    _.n = uI.prototype;
    _.n.sessionState_changed = function() {
        var a = this.get("sessionState");
        if (a) {
            var b = new _.zF;
            _.dm(b, a);
            a = _.K(b.m, 10, _.xD);
            _.D(a.m, 1, 1);
            _.D(b.m, 12, !0);
            b = _.uua(b, this.D);
            b += "&rapsrc=apiv3";
            _.en(this.g, _.vz(b));
            this.C = b;
            this.get("available") && this.set("rmiLinkData", {
                label: "B\u00e1o c\u00e1o m\u1ed9t l\u1ed7i b\u1ea3n \u0111\u1ed3",
                tooltip: "B\u00e1o c\u00e1o l\u1ed7i trong b\u1ea3n \u0111\u1ed3 \u0111\u01b0\u1eddng ho\u1eb7c h\u00ecnh \u1ea3nh \u0111\u1ebfn Google",
                url: this.C
            })
        }
    };
    _.n.available_changed = function() {
        vI(this)
    };
    _.n.enabled_changed = function() {
        vI(this)
    };
    _.n.mapTypeId_changed = function() {
        vI(this)
    };
    _.n.Xh = function() {
        Zwa(this) && (_.BA(), _.Q(this.o, "Rs"), _.P(this.o, 148263), this.h.style.display = "", this.g.textContent = "", this.g.appendChild(this.F))
    };
    _.n.Wh = function() {
        Zwa(this) && (_.BA(), _.Q(this.o, "Rs"), _.P(this.o, 148263), this.h.style.display = "", this.g.textContent = "B\u00e1o c\u00e1o m\u1ed9t l\u1ed7i b\u1ea3n \u0111\u1ed3")
    };
    _.n.Yb = function() {
        this.h.style.display = "none"
    };
    _.n.Yd = function() {
        return this.h
    };
    _.B(wI, _.O);
    wI.prototype.refresh = function() {
        var a = this.get("mapSize"),
            b = !!this.get("aerialAvailableAtZoom");
        a = !!this.get("rotateControl") || a && 200 <= a.width && 200 <= a.height;
        b = b && a;
        a = this.H;
        $wa(this.C, this.h, this.D);
        this.j.style.display = this.h ? "block" : "none";
        this.F.style.display = this.h ? "block" : "none";
        this.o.style.display = this.h ? "block" : "none";
        this.G.style.display = this.h ? "block" : "none";
        var c = this.D,
            d = Math.floor(3 * this.D) + 2;
        d = this.h ? d : this.D;
        this.g.style.width = _.jn(c);
        this.g.style.height = _.jn(d);
        a.dataset.controlWidth = String(c);
        a.dataset.controlHeight = String(d);
        _.eA(a, b);
        _.N(a, "resize")
    };
    _.B(dxa, _.O);
    _.n = fxa.prototype;
    _.n.show = function() {
        this.h && (this.fa.style.display = "")
    };
    _.n.Yb = function() {
        this.h || (this.fa.style.display = "none")
    };
    _.n.Xh = function() {
        this.show()
    };
    _.n.Wh = function() {
        this.show()
    };
    _.n.Yd = function() {
        return this.fa
    };
    ixa.prototype.update = function(a) {
        this.g = a;
        var b = _.A(this.yi);
        for (var c = b.next(); !c.done; c = b.next()) {
            var d = c.value;
            d.Yb();
            d.Xh()
        }
        if (a < this.fa.offsetWidth)
            for (d = _.A(this.Ym), c = d.next(); !c.done; c = d.next())
                if (c = c.value, b = this.fa.offsetWidth, a < b) c.Yb();
                else break;
        else
            for (d = this.Ym.length - 1; 0 <= d; d--) c = this.Ym[d], c.Wh(), b = this.fa.offsetWidth, a < b && c.Xh();
        _.N(this.fa, "resize")
    };
    var zI = {},
        tya = zI[1] = {};
    tya.backgroundColor = "#fff";
    tya.St = "#e6e6e6";
    var uya = zI[2] = {};
    uya.backgroundColor = "#222";
    uya.St = "#1a1a1a";
    _.B(AI, _.O);
    AI.prototype.changed = function(a) {
        if ("zoom" === a || "zoomRange" === a) {
            a = this.get("zoom");
            var b = this.get("zoomRange");
            "number" === typeof a && b && (this.C.disabled = a >= b.max, this.C.style.cursor = a >= b.max ? "default" : "pointer", this.D.disabled = a <= b.min, this.D.style.cursor = a <= b.min ? "default" : "pointer")
        }
    };
    _.B(BI, _.O);
    BI.prototype.getDiv = function() {
        return this.g
    };
    _.B(DI, _.O);
    _.n = DI.prototype;
    _.n.fontLoaded_changed = function() {
        CI(this)
    };
    _.n.attributionText_changed = function() {
        CI(this)
    };
    _.n.hidden_changed = function() {
        CI(this)
    };
    _.n.mapTypeId_changed = function() {
        "streetview" === this.get("mapTypeId") && (cI(this.C), this.j.style.color = "#fff")
    };
    _.n.Xh = function() {
        this.get("hidden") || (this.g.style.display = "", this.j.style.display = "", this.h.style.display = "none", _.BA())
    };
    _.n.Wh = function() {
        this.get("hidden") || (this.g.style.display = "", this.j.style.display = "none", this.h.style.display = "", _.BA())
    };
    _.n.Yb = function() {
        this.get("hidden") && (this.g.style.display = "none")
    };
    _.n.Yd = function() {
        return this.g
    };
    _.B(EI, _.O);
    EI.prototype.ob = function() {
        return this.g.element
    };
    EI.prototype.visible_changed = function() {
        this.get("visible") ? (_.BA(), this.j.appendChild(this.g.element), this.g.show()) : this.g.Yb()
    };
    EI.prototype.attributionText_changed = function() {
        var a = this.get("attributionText") || "";
        (this.h.textContent = a) || this.g.Yb()
    };
    _.B(FI, _.O);
    _.n = FI.prototype;
    _.n.attributionText_changed = function() {
        var a = this.get("attributionText") || "";
        this.h.textContent = a
    };
    _.n.hidden_changed = function() {
        var a = !this.get("hidden");
        _.eA(this.g, a);
        a && _.BA()
    };
    _.n.Xh = function() {};
    _.n.Wh = function() {};
    _.n.Yb = function() {};
    _.n.Yd = function() {
        return this.g
    };
    _.B(GI, _.O);
    _.n = GI.prototype;
    _.n.hidden_changed = function() {
        _.N(this.g, "resize")
    };
    _.n.mapTypeId_changed = function() {
        "streetview" == this.get("mapTypeId") && (cI(this.g), this.j.style.color = "#fff")
    };
    _.n.fontLoaded_changed = function() {
        _.N(this.g, "resize")
    };
    _.n.Xh = function() {
        this.Wh()
    };
    _.n.Wh = function() {
        this.get("hidden") || (this.g.style.display = "", _.BA())
    };
    _.n.Yb = function() {
        this.get("hidden") && (this.g.style.display = "none")
    };
    _.n.Yd = function() {
        return this.g
    };
    _.B(mxa, _.O);
    _.Ua(HI, _.O);
    HI.prototype.changed = function(a) {
        if ("sessionState" != a) {
            a = new _.zF;
            var b = this.get("zoom"),
                c = this.get("center"),
                d = this.get("pano");
            if (null != b && null != c || null != d) {
                var e = this.g,
                    f = _.K(a.m, 2, _.tD),
                    g = _.qd(e);
                _.D(f.m, 1, g);
                f = _.K(a.m, 2, _.tD);
                e = _.rd(e);
                _.D(f.m, 2, e);
                e = _.AF(a);
                f = this.get("mapTypeId");
                "hybrid" == f || "satellite" == f ? _.D(e.m, 1, 3) : (_.D(e.m, 1, 0), "terrain" == f && (f = _.K(a.m, 5, _.rD), _.bd(f.m, 1, 4)));
                f = _.K(e.m, 2, _.zD);
                _.D(f.m, 1, 2);
                c && (g = c.lng(), _.D(f.m, 2, g), c = c.lat(), _.D(f.m, 3, c));
                "number" === typeof b && _.D(f.m,
                    6, b);
                f.setHeading(this.get("heading") || 0);
                d && (b = _.K(e.m, 3, _.DD), _.D(b.m, 1, d));
                this.set("sessionState", a)
            } else this.set("sessionState", null)
        }
    };
    _.B(II, _.O);
    II.prototype.floors_changed = function() {
        var a = this.get("floorId"),
            b = this.get("floors") || [],
            c = this.fa;
        if (1 < b.length) {
            _.gA(c);
            _.mb(this.h, function(g) {
                _.oo(g)
            });
            this.h = [];
            for (var d = b.length, e = d - 1; 0 <= e; --e) {
                var f = _.Mr(b[e].description || b[e].ys || "T\u1ea7ng");
                b[e].Ap == a ? (f.style.color = "#aaa", f.style.fontWeight = "bold", f.style.backgroundColor = "#333") : (nxa(this, f, b[e].CC), f.style.color = "#999", f.style.fontWeight = "400", f.style.backgroundColor = "#222");
                f.style.height = f.style.width = _.jn(this.g);
                e === d - 1 ? Tva(f, _.jn(_.MC(this.g))) :
                    0 === e && Uva(f, _.jn(_.MC(this.g)));
                _.Xn(b[e].ys, f);
                c.appendChild(f);
                this.h.push(f)
            }
            setTimeout(function() {
                _.N(c, "resize")
            })
        } else _.fA(c)
    };
    _.B(JI, _.O);
    JI.prototype.o = function() {
        1 === this.get("mode") && this.set("mode", 2)
    };
    JI.prototype.C = function() {
        2 === this.get("mode") && this.set("mode", 1)
    };
    var vya = [_.Nr["lilypad_0.svg"], _.Nr["lilypad_1.svg"], _.Nr["lilypad_2.svg"], _.Nr["lilypad_3.svg"], _.Nr["lilypad_4.svg"], _.Nr["lilypad_5.svg"], _.Nr["lilypad_6.svg"], _.Nr["lilypad_7.svg"], _.Nr["lilypad_8.svg"], _.Nr["lilypad_9.svg"], _.Nr["lilypad_10.svg"], _.Nr["lilypad_11.svg"], _.Nr["lilypad_12.svg"], _.Nr["lilypad_13.svg"], _.Nr["lilypad_14.svg"], _.Nr["lilypad_15.svg"]],
        xxa = [_.Nr["lilypad_pegman_0.svg"], _.Nr["lilypad_pegman_1.svg"], _.Nr["lilypad_pegman_2.svg"], _.Nr["lilypad_pegman_3.svg"], _.Nr["lilypad_pegman_4.svg"],
            _.Nr["lilypad_pegman_5.svg"], _.Nr["lilypad_pegman_6.svg"], _.Nr["lilypad_pegman_7.svg"], _.Nr["lilypad_pegman_8.svg"], _.Nr["lilypad_pegman_9.svg"], _.Nr["lilypad_pegman_10.svg"], _.Nr["lilypad_pegman_11.svg"], _.Nr["lilypad_pegman_12.svg"], _.Nr["lilypad_pegman_13.svg"], _.Nr["lilypad_pegman_14.svg"], _.Nr["lilypad_pegman_15.svg"]
        ];
    _.B(KI, _.O);
    _.n = KI.prototype;
    _.n.kk = function() {
        _.Ca(function(a) {
            _.wa(a)
        })
    };
    _.n.lk = function() {
        _.Ca(function(a) {
            _.wa(a)
        })
    };
    _.n.mode_changed = function() {
        var a = this;
        return _.Ca(function(b) {
            if (1 == b.g) return _.va(b, yxa(a), 2);
            zxa(a);
            _.wa(b)
        })
    };
    _.n.heading_changed = function() {
        7 === this.h() && yxa(this)
    };
    _.n.position_changed = function() {
        var a = this.h();
        if (_.sG(a))
            if (this.get("position")) {
                this.nq.setVisible(!0);
                this.H.setVisible(!1);
                a = this.set;
                var b = wxa(this);
                this.D !== b && (this.D = b, this.C = {
                    url: vya[b],
                    scaledSize: new _.Fg(49, 52),
                    anchor: new _.R(25, 35)
                });
                a.call(this, "lilypadIcon", this.C)
            } else a = this.h(), 5 === a ? this.g(6) : 3 === a && this.g(4);
        else(b = this.get("position")) && 1 === a && this.g(7), this.set("dragPosition", b)
    };
    _.n.ff = function(a) {
        this.set("dragging", !0);
        this.g(5);
        this.o = a.pixel.x
    };
    _.n.og = function(a) {
        var b = this;
        a = a.pixel.x;
        a > this.o + 5 ? (this.g(5), this.o = a) : a < this.o - 5 && (this.g(3), this.o = a);
        zxa(this);
        window.clearTimeout(this.j);
        this.j = window.setTimeout(function() {
            _.N(b, "hover");
            b.j = 0
        }, 300)
    };
    _.n.Gf = function() {
        this.set("dragging", !1);
        this.g(1);
        window.clearTimeout(this.j);
        this.j = 0
    };
    _.B(LI, _.O);
    _.n = LI.prototype;
    _.n.Gd = function() {
        var a = this.map.overlayMapTypes,
            b = this.overlay;
        a.forEach(function(c, d) {
            c == b && a.removeAt(d)
        });
        this.j = !1
    };
    _.n.pd = function() {
        var a = this.get("projection");
        a && a.h && (this.map.overlayMapTypes.push(this.overlay), this.j = !0)
    };
    _.n.mode_changed = function() {
        var a = _.sG(this.G());
        a != this.j && (a ? this.pd() : this.Gd())
    };
    _.n.tilt_changed = function() {
        this.j && (this.Gd(), this.pd())
    };
    _.n.heading_changed = function() {
        this.j && (this.Gd(), this.pd())
    };
    _.n.result_changed = function() {
        var a = this.get("result"),
            b = a && a.location;
        this.set("position", b && b.latLng);
        this.set("description", b && b.shortDescription);
        this.set("panoId", b && b.pano);
        this.C ? this.o(1) : this.get("hover") || this.set("panoramaVisible", !!a)
    };
    _.n.panoramaVisible_changed = function() {
        this.C = 0 == this.get("panoramaVisible");
        var a = this.get("panoramaVisible"),
            b = this.get("hover");
        a || b || this.o(1);
        a && this.notify("position")
    };
    _.B(NI, _.O);
    _.n = NI.prototype;
    _.n.visible_changed = function() {
        var a = !1 !== this.get("visible");
        _.eA(this.fa, a);
        _.N(this.fa, "resize")
    };
    _.n.takeDownUrl_changed = function() {
        var a = this.get("pov"),
            b = this.get("pano"),
            c = this.get("takeDownUrl");
        a && (c || b) && (a = "1," + Number(Number(a.heading).toFixed(3)).toString() + ",," + Number(Number(Math.max(0, a.zoom - 1 || 0)).toFixed(3)).toString() + "," + Number(Number(-a.pitch).toFixed(3)).toString(), b = c ? c + ("&cbp=" + a + "&hl=" + _.qd(_.sd(_.td))) : this.g.getUrl("report", ["panoid=" + b, "cbp=" + a, "hl=" + _.qd(_.sd(_.td))]), _.en(this.anchor, _.vz(b)), this.set("rmiLinkData", {
            label: (MI(), "B\u00e1o c\u00e1o v\u1ea5n \u0111\u1ec1"),
            tooltip: "B\u00e1o c\u00e1o v\u1ea5n \u0111\u1ec1 v\u1ec1 h\u00ecnh \u1ea3nh \u1edf Ch\u1ebf \u0111\u1ed9 xem ph\u1ed1 v\u1edbi Google",
            url: b
        }))
    };
    _.n.pov_changed = function() {
        this.takeDownUrl_changed()
    };
    _.n.pano_changed = function() {
        this.takeDownUrl_changed()
    };
    _.n.Xh = function() {};
    _.n.Wh = function() {};
    _.n.Yb = function() {};
    _.n.Yd = function() {
        return this.fa
    };
    _.B(OI, _.O);
    _.n = OI.prototype;
    _.n.disableDefaultUI_changed = function() {
        Yxa(this)
    };
    _.n.size_changed = function() {
        Yxa(this);
        this.get("size") && this.Pd.update(this.get("size").width)
    };
    _.n.mapTypeId_changed = function() {
        PI(this) != this.Ta && (this.F[1] = !0, _.Ji(this.Ba));
        this.V && this.V.setMapTypeId(this.get("mapTypeId"))
    };
    _.n.mapTypeControl_changed = function() {
        this.F[0] = !0;
        _.Ji(this.Ba)
    };
    _.n.mapTypeControlOptions_changed = function() {
        this.F[0] = !0;
        _.Ji(this.Ba)
    };
    _.n.fullscreenControlOptions_changed = function() {
        this.F[3] = !0;
        _.Ji(this.Ba)
    };
    _.n.scaleControl_changed = function() {
        SI(this)
    };
    _.n.scaleControlOptions_changed = function() {
        SI(this)
    };
    _.n.keyboardShortcuts_changed = function() {
        var a = !!(this.g && _.Im(this.g) || this.h);
        a ? (this.ga.fa.style.display = "", this.C.set("keyboardShortcutsShown", !0)) : a || (this.ga.fa.style.display = "none", this.C.set("keyboardShortcutsShown", !1))
    };
    _.n.panControl_changed = function() {
        RI(this)
    };
    _.n.panControlOptions_changed = function() {
        RI(this)
    };
    _.n.rotateControl_changed = function() {
        RI(this)
    };
    _.n.rotateControlOptions_changed = function() {
        RI(this)
    };
    _.n.streetViewControl_changed = function() {
        RI(this)
    };
    _.n.streetViewControlOptions_changed = function() {
        RI(this)
    };
    _.n.zoomControl_changed = function() {
        RI(this)
    };
    _.n.zoomControlOptions_changed = function() {
        RI(this)
    };
    _.n.myLocationControl_changed = function() {
        RI(this)
    };
    _.n.myLocationControlOptions_changed = function() {
        RI(this)
    };
    _.n.streetView_changed = function() {
        hya(this)
    };
    _.n.fw = function(a) {
        this.get("panoramaVisible") != a && this.set("panoramaVisible", a)
    };
    _.n.panoramaVisible_changed = function() {
        var a = this.get("streetView");
        a && (this.H && a.__gm.bindTo("sloTrackingId", this.H), a.g.set(!!this.get("panoramaVisible")))
    };
    var iya = _.Vl(_.ab(".dismissButton{background-color:#fff;border:1px solid #dadce0;color:#1a73e8;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;font-family:Roboto,sans-serif;font-size:14px;height:36px;cursor:pointer;padding:0 24px}.dismissButton:hover{background-color:rgba(66,133,244,.04);border:1px solid #d2e3fc}.dismissButton:focus{background-color:rgba(66,133,244,.12);border:1px solid #d2e3fc;outline:0}.dismissButton:focus:not(:focus-visible){background-color:#fff;border:1px solid #dadce0;outline:none}.dismissButton:focus-visible{background-color:rgba(66,133,244,.12);border:1px solid #d2e3fc;outline:0}.dismissButton:hover:focus{background-color:rgba(66,133,244,.16);border:1px solid #d2e2fd}.dismissButton:hover:focus:not(:focus-visible){background-color:rgba(66,133,244,.04);border:1px solid #d2e3fc}.dismissButton:hover:focus-visible{background-color:rgba(66,133,244,.16);border:1px solid #d2e2fd}.dismissButton:active{background-color:rgba(66,133,244,.16);border:1px solid #d2e2fd;-webkit-box-shadow:0 1px 2px 0 rgba(60,64,67,.3),0 1px 3px 1px rgba(60,64,67,.15);-moz-box-shadow:0 1px 2px 0 rgba(60,64,67,.3),0 1px 3px 1px rgba(60,64,67,.15);box-shadow:0 1px 2px 0 rgba(60,64,67,.3),0 1px 3px 1px rgba(60,64,67,.15)}.dismissButton:disabled{background-color:#fff;border:1px solid #f1f3f4;color:#3c4043}sentinel{}\n"));
    var wya = new _.w.Set([3, 12, 6, 9]);
    _.B(TI, _.O);
    TI.prototype.getSize = function() {
        return _.hj(this.h)
    };
    TI.prototype.addElement = function(a, b, c, d) {
        var e = this;
        c = void 0 === c ? !1 : c;
        var f = this.g.get(b);
        if (f) {
            d = void 0 !== d && _.Wd(d) ? d : f.length;
            var g;
            for (g = 0; g < f.length && !(f[g].index > d); ++g);
            f.splice(g, 0, {
                element: a,
                border: !!c,
                index: d,
                listener: _.M(a, "resize", function() {
                    return _.Ji(e.Ba)
                })
            });
            _.Zn(a);
            a.style.visibility = "hidden";
            c = this.o.get(b);
            b = wya.has(b) ? f.length - g - 1 : g;
            c.insertBefore(a, c.children[b]);
            _.Ji(this.Ba)
        }
    };
    TI.prototype.Fd = function(a) {
        a.parentNode && a.parentNode.removeChild(a);
        for (var b = _.A(_.u(this.g, "values").call(this.g)), c = b.next(); !c.done; c = b.next()) {
            c = c.value;
            for (var d = 0; d < c.length; ++d)
                if (c[d].element === a) {
                    var e = a;
                    e.style.top = "auto";
                    e.style.bottom = "auto";
                    e.style.left = "auto";
                    e.style.right = "auto";
                    _.gf(c[d].listener);
                    c.splice(d, 1)
                }
        }
        _.Ji(this.Ba)
    };
    TI.prototype.j = function() {
        var a = this.getSize(),
            b = a.width;
        a = a.height;
        var c = this.g,
            d = [],
            e = WI(c.get(1), "left", "top", d),
            f = XI(c.get(5), "left", "top", d);
        d = [];
        var g = WI(c.get(10), "left", "bottom", d),
            h = XI(c.get(6), "left", "bottom", d);
        d = [];
        var k = WI(c.get(3), "right", "top", d),
            l = XI(c.get(7), "right", "top", d);
        d = [];
        var m = WI(c.get(12), "right", "bottom", d);
        d = XI(c.get(9), "right", "bottom", d);
        var p = lya(c.get(11), "bottom", b),
            q = lya(c.get(2), "top", b),
            r = YI(c.get(4), "left", b, a);
        YI(c.get(13), "center", b, a);
        c = YI(c.get(8), "right",
            b, a);
        this.set("bounds", new _.Ki([new _.R(Math.max(r, e.width, g.width, f.width, h.width) || 0, Math.max(q, e.height, f.height, k.height, l.height) || 0), new _.R(b - (Math.max(c, k.width, m.width, l.width, d.width) || 0), a - (Math.max(p, g.height, m.height, h.height, d.height) || 0))]))
    };
    var xya = [37, 38, 39, 40],
        yya = [38, 40],
        zya = [37, 39],
        Aya = {
            38: [0, -1],
            40: [0, 1],
            37: [-1, 0],
            39: [1, 0]
        },
        Bya = {
            38: [0, 1],
            40: [0, -1],
            37: [-1, 0],
            39: [1, 0]
        };
    var cJ = Object.freeze([].concat(_.oa(yya), _.oa(zya)));
    _.B(ZI, _.O);
    _.n = ZI.prototype;
    _.n.KA = function(a) {
        if (qya(this, a)) return !0;
        var b = !1;
        switch (a.keyCode) {
            case 38:
            case 40:
            case 37:
            case 39:
                b = a.shiftKey && 0 <= yya.indexOf(a.keyCode);
                var c = a.shiftKey && 0 <= zya.indexOf(a.keyCode) && this.J && !this.h;
                b && this.M && !this.h || c ? (this.F[a.keyCode] = !0, this.j || (this.G = 0, this.g = 1, this.Ut()), $I(b ? 165376 : 165375, b ? "Tmki" : "Rmki")) : this.j || (this.C[a.keyCode] = 1, this.h || (this.o = new _.tG(100), this.Tt()), $I(165373, "Pmki"));
                b = !0;
                break;
            case 34:
                aJ(this, 0, .75);
                b = !0;
                break;
            case 33:
                aJ(this, 0, -.75);
                b = !0;
                break;
            case 36:
                aJ(this, -.75, 0);
                b = !0;
                break;
            case 35:
                aJ(this, .75, 0);
                b = !0;
                break;
            case 187:
            case 107:
                oya(this);
                b = !0;
                break;
            case 189:
            case 109:
                pya(this), b = !0
        }
        switch (a.which) {
            case 61:
            case 43:
                oya(this);
                b = !0;
                break;
            case 45:
            case 95:
            case 173:
                pya(this), b = !0
        }
        b && (_.Ye(a), _.cf(a));
        return !b
    };
    _.n.Py = function(a) {
        if (qya(this, a)) return !0;
        switch (a.keyCode) {
            case 38:
            case 40:
            case 37:
            case 39:
            case 34:
            case 33:
            case 36:
            case 35:
            case 187:
            case 107:
            case 189:
            case 109:
                return _.Ye(a), _.cf(a), !1
        }
        switch (a.which) {
            case 61:
            case 43:
            case 45:
            case 95:
            case 173:
                return _.Ye(a), _.cf(a), !1
        }
        return !0
    };
    _.n.TC = function(a) {
        var b = !1;
        switch (a.keyCode) {
            case 38:
            case 40:
            case 37:
            case 39:
                this.C[a.keyCode] = null, this.F[a.keyCode] = !1, b = !0
        }
        return !b
    };
    _.n.Tt = function() {
        for (var a = 0, b = 0, c = !1, d = _.A(xya), e = d.next(); !e.done; e = d.next()) e = e.value, this.C[e] && (e = _.A(Aya[e]), c = e.next().value, e = e.next().value, a += c, b += e, c = !0);
        c ? (c = 1, _.uG(this.o) && (c = this.o.next()), d = Math.round(35 * c * a), c = Math.round(35 * c * b), 0 === d && (d = a), 0 === c && (c = b), _.N(this, "panbynow", d, c, 1), this.h = _.Yz(this, this.Tt, 10)) : this.h = 0
    };
    _.n.Ut = function() {
        for (var a = 0, b = 0, c = !1, d = 0; d < cJ.length; d++) this.F[cJ[d]] && (c = Bya[cJ[d]], a += c[0], b += c[1], c = !0);
        c ? (_.N(this, "tiltrotatebynow", this.g * a, this.g * b), this.j = _.Yz(this, this.Ut, 10), this.g = Math.min(1.8, this.g + .01), this.G++, this.H = {
            x: a,
            y: b
        }) : (this.j = 0, this.D = new _.tG(Math.min(Math.round(this.G / 2), 35), 1), _.Yz(this, this.Vt, 10))
    };
    _.n.Vt = function() {
        if (!this.j && !this.h && _.uG(this.D)) {
            var a = this.H,
                b = a.x;
            a = a.y;
            var c = this.D.next();
            _.N(this, "tiltrotatebynow", this.g * c * b, this.g * c * a);
            _.Yz(this, this.Vt, 10)
        }
    };
    bJ.prototype.Xv = function(a, b) {
        a = _.jya(a, b).style;
        a.border = "1px solid rgba(0,0,0,0.12)";
        a.borderRadius = "5px";
        a.left = "50%";
        a.maxWidth = "375px";
        a.msTransform = "translateX(-50%)";
        a.position = "absolute";
        a.transform = "translateX(-50%)";
        a.width = "calc(100% - 10px)";
        a.zIndex = "1"
    };
    bJ.prototype.wr = function(a) {
        if (_.Dda() && !a.__gm_bbsp) {
            a.__gm_bbsp = !0;
            var b = new _.Pn("https://developers.google.com/maps/documentation/javascript/error-messages#unsupported-browsers");
            new Dwa(a, b)
        }
    };
    _.Ue("controls", new bJ);
});