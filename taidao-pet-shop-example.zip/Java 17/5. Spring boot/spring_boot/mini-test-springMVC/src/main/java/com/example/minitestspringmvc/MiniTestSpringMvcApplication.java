package com.example.minitestspringmvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiniTestSpringMvcApplication {

    public static void main(String[] args) {
        SpringApplication.run(MiniTestSpringMvcApplication.class, args);
    }

}
